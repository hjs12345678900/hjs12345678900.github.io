"""Render twelve true DSS2 Red maps and a readable four-row annual overview.

Map coordinates are ICRS CAR, north up/east left. The already validated real
survey preview is reused byte-for-byte; plotting never creates sky features.
"""
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[2]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'assets/mplcache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import numpy as np
import pandas as pd
from PIL import Image

FONT=FontProperties(fname='/System/Library/Fonts/Supplemental/Arial Unicode.ttf') if Path('/System/Library/Fonts/Supplemental/Arial Unicode.ttf').exists() else FontProperties(family=['DejaVu Sans'])


def panel(ax,image,counts,ra,dec,month,small=False):
    """Draw the real RGB preview with a visibility alpha mask, not painted data.

    Counts have axes (altitude, moon, site, dec, ra); counts/12 are hours.
    Default contours require each site independently >=10h, lunar altitude<0.
    The cyan/gold contours correspond to target altitude >=30/40 degrees.
    """
    hours=np.minimum(counts[0,1,0],counts[0,1,1])/12
    preferred=np.minimum(counts[1,1,0],counts[1,1,1])/12
    mask=np.asarray(Image.fromarray((hours>=10)[::-1,::-1].astype(np.uint8)*255).resize((image.shape[1],image.shape[0]),Image.Resampling.NEAREST))/255
    shown=np.power(image.astype(float)/255,1/1.8)*(.10+.90*mask[...,None])
    ax.imshow(shown,extent=[360,0,-30,30],origin='upper',aspect='auto')
    ax.contour(ra,dec,hours,levels=[10],colors=['#20e0df'],linewidths=.8 if small else 1.2)
    ax.contour(ra,dec,preferred,levels=[10],colors=['#ffc065'],linewidths=.8 if small else 1.2,linestyles='--')
    ax.set_xlim(360,0);ax.set_ylim(-30,30)
    ticks=np.arange(0,361,60 if small else 30)
    ax.set_xticks(ticks,labels=[f'{int(v/15)}h' for v in ticks])
    ax.set_yticks([-30,0,30] if small else [-30,-20,-10,0,10,20,30])
    ax.tick_params(colors='#ddd7e1',labelsize=9 if small else 11)
    ax.grid(color='white',alpha=.12,lw=.5)
    for spine in ax.spines.values():spine.set_color('#51485b')
    ax.set_title(f'2027年{month}月',loc='left',fontproperties=FONT,color='white',fontsize=14 if small else 19)
    if not small:ax.set_ylabel('赤纬 / Dec',fontproperties=FONT,color='#ddd7e1')


def main():
    z=np.load(ROOT/'data/monthly_sky_counts.npz');v=z['counts'];ra=z['ra_deg'];dec=z['dec_deg']
    raw=Image.open(ROOT/'assets/dss2_red_car_preview.jpg').convert('RGB')
    image=np.asarray(raw.resize((3600,600),Image.Resampling.LANCZOS))
    overview_image=np.asarray(raw.resize((1440,240),Image.Resampling.LANCZOS))
    fig,axes=plt.subplots(4,3,figsize=(24,15),facecolor='#100e1b')
    area=[]
    cell_area=np.deg2rad(.25)*(np.sin(np.deg2rad(dec+.125))-np.sin(np.deg2rad(dec-.125)))*(180/np.pi)**2
    for mi in range(12):
        panel(axes.flat[mi],overview_image,v[mi],ra,dec,mi+1,True)
        single,ax=plt.subplots(figsize=(24,6),facecolor='#100e1b')
        panel(ax,image,v[mi],ra,dec,mi+1)
        ax.set_xlabel('赤经 / RA（东在左）',fontproperties=FONT,color='#ddd7e1')
        single.text(.06,.03,'真实 DSS2 Red / STScI–NASA–CDS · 青线：两站各≥10h@30°；金虚线：各≥10h@40° · 月亮落下 · 几何上限，未扣天气/地形。',fontproperties=FONT,color='#c6bcc9',fontsize=12)
        single.subplots_adjust(left=.06,right=.985,bottom=.18,top=.88)
        single.savefig(ROOT/f'figures/2027_{mi+1:02}_dss_mask.png',dpi=150,facecolor=single.get_facecolor());plt.close(single)
        for hi,height in enumerate([30,40]):
            for moon in [0,1]:
                for simultaneous in [False,True]:
                    h=(v[mi,hi,moon,2] if simultaneous else np.minimum(v[mi,hi,moon,0],v[mi,hi,moon,1]))/12
                    for threshold in [1,10,20,40]:
                        area.append({'month':f'2027-{mi+1:02}','altitude_deg':height,'moon_down':bool(moon),
                                     'simultaneous':simultaneous,'minimum_hours':threshold,
                                     'area_square_deg':float(np.sum((h>=threshold)*cell_area[:,None]))})
    fig.text(.04,.98,'甘肃 × ASV：2027 全年每月共同天区 · DSS2 Red',fontproperties=FONT,color='white',fontsize=24)
    fig.text(.04,.948,'保留真实巡天：两站可分别累计，各≥10h；不要求同步。青线：高度≥30°；金虚线：≥40°。均筛选月亮落下。',fontproperties=FONT,color='#c6bcc9',fontsize=14)
    fig.text(.04,.018,'北上东左；全赤经24小时，赤纬−30°至+30°。完整5分钟UTC网格；ASV逐时刻处理AEDT/AEST。约7′采样的摄影预览，不是窄带或面亮度模型。',fontproperties=FONT,color='#c6bcc9',fontsize=12)
    fig.subplots_adjust(left=.04,right=.985,top=.91,bottom=.065,wspace=.12,hspace=.38)
    fig.savefig(ROOT/'figures/monthly_overlap_overview.png',dpi=170,facecolor=fig.get_facecolor());plt.close(fig)
    pd.DataFrame(area).to_csv(ROOT/'tables/monthly_sky_areas.csv',index=False,encoding='utf-8-sig')
    print('Rendered twelve monthly maps and annual overview',flush=True)


if __name__=='__main__':main()

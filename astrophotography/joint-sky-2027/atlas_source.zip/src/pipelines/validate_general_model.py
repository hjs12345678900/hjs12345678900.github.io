"""Build independent full AltAz references for default, polar and date-line sites."""
from pathlib import Path
import sys,json
import numpy as np
import astropy.units as u
from astropy.coordinates import SkyCoord,EarthLocation,AltAz
from astropy.time import Time
from astropy.table import Table
from astropy.utils import iers
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/scientific_core'))
from annual_ephemeris import evening_labels,sun_moon_altitudes

def main():
    iers.conf.auto_download=False; iers.conf.auto_max_age=None; iers.conf.iers_degraded_accuracy='warn'
    iers.earth_orientation_table.set(iers.IERS_A(Table.read(ROOT/'data/raw/iers_a_frozen.ecsv',format='ascii.ecsv')))
    pairs=[[(38.826387,103.3294496,'Asia/Shanghai',30),(-36.727973,143.269703,'Australia/Melbourne',30)],[(20,179,'Pacific/Fiji',17),(-25,-179,'Pacific/Honolulu',43)],[(90,0,'UTC',10),(65,25,'Europe/Helsinki',25)]]
    rows=[]
    for pair in pairs:
      for month in ['2027-01','2027-06','2027-12']:
        start=Time(month+'-01').unix; m=int(month[-2:]);end=Time('2028-01-01' if m==12 else f'2027-{m+1:02}-01').unix
        times=Time(np.arange(start-86400+150,end+172800,300),format='unix')
        prepared=[]
        for lat,lon,zone,h in pair:
          labels,valid,_=evening_labels(times,zone,2027)
          sun,moon=sun_moon_altitudes(times,lat,lon)
          prepared.append((valid&np.char.startswith(labels,month)&(sun< -18),moon,AltAz(obstime=times,location=EarthLocation.from_geodetic(lon*u.deg,lat*u.deg),pressure=0*u.hPa)))
        for ra,dec in [(90,0),(270,65),(359,-55),(20,89.9)]:
          alts=[SkyCoord(ra*u.deg,dec*u.deg).transform_to(frame).alt.deg for _,_,frame in prepared]
          for down in [False,True]:
            masks=[valid&(alt>=p[3])&((moon<0) if down else True) for p,(valid,moon,_),alt in zip(pair,prepared,alts)]
            rows.append(dict(sites=[dict(name=str(i),lat=p[0],lon=p[1],zone=p[2],height=p[3]) for i,p in enumerate(pair)],month=month,moon=down,ra=ra,dec=dec,hours=[float(np.sum(a)/12) for a in [*masks,masks[0]&masks[1]]]))
    (ROOT/'data/general_reference.json').write_text(json.dumps(rows))
    print(len(rows),'reference cases')
if __name__=='__main__':main()

"""Integrate twelve monthly celestial visibility maps and a browser point model.

Every original five-minute cell is used. Only the slowly changing ICRS→CIRS
direction mapping is approximated at each month's midpoint; independent full
AltAz comparisons are performed in validate_annual_model.py.
"""
from pathlib import Path
import base64,hashlib,json,sys
import numpy as np
from astropy.io import fits
from astropy.table import Table
from astropy.time import Time
from astropy.utils import iers
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/scientific_core'))
from monthly_sky_geometry import MONTHS,SITES,apparent_directions,monthly_counts


def encode(array):
    """Serialize row-major little-endian float32 radians as browser base64."""
    return base64.b64encode(np.asarray(array,dtype='<f4').tobytes()).decode()


def main():
    config=json.loads((ROOT/'config.json').read_text())
    assert config['months']==MONTHS and config['step_seconds']==300
    iers.conf.auto_download=False;iers.conf.auto_max_age=None
    iers.conf.iers_degraded_accuracy='warn'
    iers.earth_orientation_table.set(iers.IERS_A(Table.read(ROOT/'data/raw/iers_a_frozen.ecsv',format='ascii.ecsv')))
    z=np.load(ROOT/'data/raw/visibility_samples.npz')
    times=Time(z['midpoint_jd_utc'],format='jd',scale='utc')
    era=times.earth_rotation_angle('tio').rad
    theta={s:(era+np.deg2rad(lon))%(2*np.pi) for s,(lat,lon) in SITES.items()}
    ras=np.arange(.125,360,.25);decs=np.arange(-29.875,30,.25)
    rr,dd=np.meshgrid(ras,decs)
    values=np.zeros((12,2,2,3,len(decs),len(ras)),dtype=np.uint16)
    payload={'months':MONTHS,'sites':SITES,'step_seconds':300,
             'timezones':{'gansu':'Asia/Shanghai','asv':'Australia/Melbourne'},
             'first_edge_unix':float(z['edges_unix_utc'][0]),'theta_g':encode(theta['gansu']),
             'correction_step_deg':1,'correction_dec_min':-30,'correction_rows':61,'correction_cols':360,
             'model':'Monthly midpoint CIRS; full five-minute UTC/Sun/Moon grid',
             'eligible':{},'correction':{}}
    for mi,month in enumerate(MONTHS):
        ra,dec=apparent_directions(rr,dd,month)
        rc,dc=np.meshgrid(np.arange(360),np.arange(-30,31))
        ac,bc=apparent_directions(rc,dc,month)
        payload['correction'][month]={'dra':encode((ac-np.deg2rad(rc)+np.pi)%(2*np.pi)-np.pi),
                                     'ddec':encode(bc-np.deg2rad(dc))}
        for moon_index,moon_down in enumerate([False,True]):
            allowed={s:z[s+'_valid']&np.char.startswith(z[s+'_night'],month)&(z[s+'_sun_alt_deg']< -18) for s in SITES}
            if moon_down:
                for s in SITES:allowed[s]&=z[s+'_moon_alt_deg']<0
            allowed['simultaneous']=allowed['gansu']&allowed['asv']
            key=month+('/moon_down' if moon_down else '/all_moon')
            payload['eligible'][key]={s:np.flatnonzero(m).tolist() for s,m in allowed.items()}
            ordered={s:np.sort(theta['asv' if s=='asv' else 'gansu'][m]) for s,m in allowed.items()}
            for hi,height in enumerate([30,40]):
                result=monthly_counts(ra,dec,ordered,height)
                for si,site in enumerate(['gansu','asv','simultaneous']):values[mi,hi,moon_index,si]=result[site]
        print(month,'integrated',flush=True)
    assert np.all(values[:,:,:,2]<=np.minimum(values[:,:,:,0],values[:,:,:,1]))
    assert np.all(values[:,1]<=values[:,0]) and np.all(values[:,:,1]<=values[:,:,0])
    np.savez_compressed(ROOT/'data/monthly_sky_counts.npz',counts=values,ra_deg=ras,dec_deg=decs)
    (ROOT/'data/point_model.json').write_text(json.dumps(payload,separators=(',',':')))
    hdus=[fits.PrimaryHDU()]
    for mi,month in enumerate(MONTHS):
        for hi,height in enumerate([30,40]):
            for moon in [0,1]:
                for si,site in enumerate(['gansu','asv','simultaneous']):
                    h=fits.ImageHDU(values[mi,hi,moon,si,:,::-1].astype(np.float32)/12,name=f'M{mi+1:02}_H{height}_L{moon}_{site[:3]}')
                    h.header.update(CTYPE1='RA---CAR',CTYPE2='DEC--CAR',CRVAL1=180.,CRVAL2=0.,
                                    CRPIX1=(len(ras)+1)/2,CRPIX2=(len(decs)+1)/2,CDELT1=-.25,CDELT2=.25,
                                    RADESYS='ICRS',BUNIT='hour',MONTH=month,MOONDOWN=bool(moon),ALTMIN=height,SITE=site)
                    hdus.append(h)
    fits.HDUList(hdus).writeto(ROOT/'data/monthly_sky_hours_wcs.fits',overwrite=True)
    facts={'version':'2.0.0','months':MONTHS,'layers':144,'map_step_deg':.25,'time_step_minutes':5,
           'model_sha256':hashlib.sha256((ROOT/'data/point_model.json').read_bytes()).hexdigest(),
           'source_sha256':hashlib.sha256((ROOT/'data/raw/visibility_samples.npz').read_bytes()).hexdigest(),
           'assumptions':'Geometric horizon; no terrain/weather; monthly CIRS directions; exact cached Sun/Moon'}
    (ROOT/'data/calculation_metadata.json').write_text(json.dumps(facts,indent=2))


if __name__=='__main__':main()

// Independently exercise the browser's interpolated model against full AltAz.
// This is a Node runner for deterministic math and IANA civil-time conversion.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..');
const raw=fs.readFileSync(path.join(root,'data/point_model.json'),'utf8');
const context=vm.createContext({window:{},document:{getElementById(){return{textContent:raw};}},atob,Intl,Date,Uint8Array,Float32Array,Math,Object,Array});
vm.runInContext(fs.readFileSync(path.join(root,'assets/sky_model.js'),'utf8'),context);
const model=context.window.SkyModel;
const rows=JSON.parse(fs.readFileSync(path.join(root,'tables/browser_reference.json'),'utf8'));
let maximum=0;
for(const r of rows){
 const value=model.evaluate(r.ra_deg,r.dec_deg,{month:r.month,height:r.height,moon:r.moon});
 const difference=Math.abs(value[r.site]-r.hours)*60;maximum=Math.max(maximum,difference);
 assert(difference<=10.0001,JSON.stringify({...r,difference}));
 assert(value.simultaneous<=Math.min(value.gansu,value.asv)+1e-8);
}
const cases=[
 ['2027-04-03T15:59:00Z','2027-04-04 02:59 UTC+11:00'],
 ['2027-04-03T16:00:00Z','2027-04-04 02:00 UTC+10:00'],
 ['2027-10-02T15:59:00Z','2027-10-03 01:59 UTC+10:00'],
 ['2027-10-02T16:00:00Z','2027-10-03 03:00 UTC+11:00'],
 ['2028-01-01T01:00:00Z','2028-01-01 12:00 UTC+11:00']
];
for(const [iso,expected]of cases)assert.equal(model.local(Date.parse(iso),'asv'),expected);
assert.equal(model.night(Date.parse('2027-04-03T16:00:00Z'),'asv'),'2027-04-03');
assert.equal(model.night(Date.parse('2027-10-02T16:00:00Z'),'asv'),'2027-10-02');
assert.equal(model.night(Date.parse('2027-12-31T16:00:00Z'),'asv'),'2027-12-31');
const seasons=[];
for(const month of model.raw.months){
 const ra=((+month.slice(-2)+2)*30)%360;
 const state={month,height:40,moon:true};
 for(const site of ['gansu','asv','simultaneous']){
  const result=model.longest(ra,0,state,site);
  if(result){assert(result.end>result.start);assert(Math.abs((result.end-result.start)/3600000-result.hours)<1e-9);}
  seasons.push({month,ra,site,longest:result});
 }
}
const report={comparisons:rows.length,max_difference_from_full_altaz_minutes:maximum,
              timezone_transitions:cases,midnight_evening_labels_verified:true,
              longest_windows:seasons};
fs.writeFileSync(path.join(root,'data/browser_model_validation.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({comparisons:rows.length,max_difference_minutes:maximum,dst_cases:cases.length}));

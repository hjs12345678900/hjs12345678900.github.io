// Playwright CLI callback: annual controls, real survey, civil time and export.
async(page)=>{
 const checks=[],months=[],errors=[],tiles=[];
 const check=(ok,label)=>{if(!ok)throw Error(label);checks.push(label);};
 page.on('pageerror',e=>errors.push(String(e)));
 page.on('response',r=>{if(/china-vo.org.*Norder[6-9].*jpg/.test(r.url())&&r.ok())tiles.push(r.url());});
 await page.setViewportSize({width:1440,height:1000});
 await page.waitForFunction(()=>window.SkyModel&&window.atlasQA?.live,{},{timeout:45000});
 check(await page.locator('#month option').count()===12,'All twelve months available');
 const coverage=await page.evaluate(()=>Array.from({length:12},(_,i)=>{
  const ra=i*30+1,p=liveAtlas.world2pix(ra,0),r=document.getElementById('sky').getBoundingClientRect();
  return{ra,visible:!!p&&p[0]>=-1&&p[0]<=r.width+1&&p[1]>=0&&p[1]<=r.height};
 }));
 check(coverage.every(v=>v.visible),'Full-year overview includes every right ascension');
 for(let i=1;i<=12;i++){
  const month=`2027-${String(i).padStart(2,'0')}`;
  await page.locator('#month').selectOption(month);
  await page.waitForFunction(m=>atlasQA.state.month===m,month);
  const point=await page.evaluate(({month,ra})=>{
   SkyAtlas.pick(ra,0);const state=SkyAtlas.state(),value=SkyAtlas.evaluate(ra,0,state);
   const win=SkyModel.longest(ra,0,state,'asv');
   return{month,maskPixels:atlasQA.passingMaskPixels,value,asvLongest:win,
          local:win?SkyModel.local(win.start,'asv'):null};
  },{month,ra:(i+2)*30%360});
  check(point.value.simultaneous<=Math.min(point.value.gansu,point.value.asv)+1e-8,month+' intersection bounded');
  if(i===7)check(point.local?.includes('UTC+10:00'),'Winter ASV displays AEST');
  if(i===12)check(point.local?.includes('UTC+11:00'),'December ASV displays AEDT');
  months.push(point);
 }
 check(new Set(months.map(m=>m.maskPixels)).size>=10,'Masks recompute throughout the annual cycle');
 const transitions=await page.evaluate(()=>[
  SkyModel.local(Date.parse('2027-04-03T15:59:00Z'),'asv'),
  SkyModel.local(Date.parse('2027-04-03T16:00:00Z'),'asv'),
  SkyModel.local(Date.parse('2027-10-02T15:59:00Z'),'asv'),
  SkyModel.local(Date.parse('2027-10-02T16:00:00Z'),'asv'),
  SkyModel.night(Date.parse('2027-12-31T16:00:00Z'),'asv')]);
 check(transitions.join('|')==='2027-04-04 02:59 UTC+11:00|2027-04-04 02:00 UTC+10:00|2027-10-03 01:59 UTC+10:00|2027-10-03 03:00 UTC+11:00|2027-12-31','DST folds, gaps and cross-year evening label correct');
 await page.locator('#month').selectOption('2027-07');
 await page.waitForFunction(()=>atlasQA.state.month==='2027-07');
 await page.screenshot({path:'output/playwright/annual-july-wide.png',fullPage:true});
 await page.locator('#mode').selectOption('simultaneous');
 await page.waitForFunction(()=>atlasQA.state.mode==='simultaneous');
 await page.locator('#moon').uncheck();await page.locator('#height').selectOption('40');
 await page.waitForFunction(()=>!atlasQA.state.moon&&atlasQA.state.height===40);
 check(true,'Simultaneous, lunar and altitude controls update');
 await page.locator('#month').selectOption('2027-01');await page.locator('#mode').selectOption('common');await page.locator('#moon').check();
 await page.evaluate(()=>SkyAtlas.pick(86.6908333333,.0791666667));
 await page.locator('#zoom-point').click();
 await page.waitForResponse(r=>/china-vo.org.*Norder[6-9].*jpg/.test(r.url())&&r.ok(),{timeout:30000}).catch(()=>{});
 check(tiles.length>0,'Real high-order DSS2 Red tiles load');
 await page.waitForFunction(()=>atlasQA.state.month==='2027-01'&&atlasQA.state.height===40);
 await page.locator('#add-point').click();
 const pending=page.waitForEvent('download');await page.locator('#export').click();const download=await pending;
 check(download.suggestedFilename()==='my_joint_sky_selections_2027.csv','Annual CSV filename');
 await download.saveAs('output/playwright/annual-selection.csv');
 await page.setViewportSize({width:390,height:844});
 await page.waitForFunction(()=>Math.abs(atlasQA.geometry.width-document.getElementById('sky').getBoundingClientRect().width)<1);
 check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Mobile layout has no horizontal overflow');
 await page.screenshot({path:'output/playwright/annual-mobile.png',fullPage:true});
 await page.setViewportSize({width:1440,height:1000});await page.locator('#zoom-point').click();
 await page.waitForFunction(()=>Math.abs(atlasQA.geometry.width-document.getElementById('sky').getBoundingClientRect().width)<1);
 await page.screenshot({path:'output/playwright/annual-desktop.png',fullPage:true});
 check(errors.length===0,'No browser runtime errors');
 await page.evaluate(value=>window.annualWebsiteQA=value,{checks,months,transitions,coverage,tiles,errors});
}

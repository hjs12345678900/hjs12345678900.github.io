"""Freeze complete-year Sun/Moon/UTC constraints, DST offsets and IERS evidence."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,platform,sys,warnings
import astropy
import numpy as np
from astropy.table import Table
from astropy.utils import iers
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/scientific_core'))
from annual_ephemeris import time_grid,evening_labels,sun_moon_altitudes


def main():
    config=json.loads((ROOT/'config.json').read_text())
    iers.conf.auto_download=False;iers.conf.auto_max_age=None
    iers.conf.iers_degraded_accuracy='warn'
    frozen=ROOT/'data/raw/iers_a_frozen.ecsv'
    earth=iers.IERS_A(Table.read(frozen,format='ascii.ecsv'))
    iers.earth_orientation_table.set(earth)
    edges,times=time_grid(config['year'],config['step_seconds'])
    arrays={'edges_unix_utc':edges,'midpoint_jd_utc':times.jd}
    notes=[]
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter('always')
        _,status=earth.ut1_utc(times,return_status=True)
        arrays['iers_ut1_status']=status
        for site,info in config['sites'].items():
            labels,valid,offsets=evening_labels(times,info['timezone'],config['year'])
            sun,moon=sun_moon_altitudes(times,info['latitude'],info['longitude'])
            arrays.update({site+'_night':labels,site+'_valid':valid,
                           site+'_utc_offset_hours':offsets,site+'_sun_alt_deg':sun,
                           site+'_moon_alt_deg':moon})
            print(site,'complete:',len(times),'five-minute cells; offsets',np.unique(offsets),flush=True)
        notes=sorted(set(str(w.message) for w in recorded))
    both=(arrays['gansu_sun_alt_deg']< -18)&(arrays['asv_sun_alt_deg']< -18)
    assert np.all(arrays['gansu_night'][both]==arrays['asv_night'][both])
    output=ROOT/'data/raw/visibility_samples.npz'
    np.savez_compressed(output,**arrays)
    transitions=[]
    offsets=arrays['asv_utc_offset_hours']
    for index in np.flatnonzero(np.diff(offsets)):
        transitions.append({'first_sample_after_transition_utc':times[index+1].isot,
                            'before_hours':float(offsets[index]),'after_hours':float(offsets[index+1])})
    values,counts=np.unique(status,return_counts=True)
    facts={'completed_utc':datetime.now(timezone.utc).isoformat(),'config':config,
           'sample_count':len(times),'first_midpoint_utc':times[0].isot,'last_midpoint_utc':times[-1].isot,
           'python':sys.version,'platform':platform.platform(),'astropy':astropy.__version__,
           'iers_sha256':hashlib.sha256(frozen.read_bytes()).hexdigest(),
           'iers_mjd_range':[float(earth['MJD'][0].value),float(earth['MJD'][-1].value)],
           'iers_status_counts':dict(zip(map(str,values),map(int,counts))),
           'outside_iers_prediction_cells':int(np.sum(status<0)),
           'asv_dst_transitions':transitions,'warnings':notes,
           'source_sha256':hashlib.sha256(output.read_bytes()).hexdigest()}
    (ROOT/'data/ephemeris_metadata.json').write_text(json.dumps(facts,indent=2))
    print(json.dumps(facts,indent=2),flush=True)


if __name__=='__main__':main()

"""Compare twelve full monthly maps to independent time-dependent Astropy AltAz.

The synthetic ICRS grid spans all right ascensions and both shared altitude
boundaries; real M78/IC443 coordinates anchor comparisons to the Q1 release.
Only the cached Sun/Moon constraints are shared with the production model.
"""
from pathlib import Path
import json,sys,warnings
import astropy.units as u
import numpy as np
import pandas as pd
from astropy.coordinates import AltAz,EarthLocation,SkyCoord
from astropy.table import Table
from astropy.time import Time
from astropy.utils import iers
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/scientific_core'))
from monthly_sky_geometry import MONTHS,SITES,apparent_directions,monthly_counts


def main():
    iers.conf.auto_download=False;iers.conf.auto_max_age=None
    iers.conf.iers_degraded_accuracy='warn'
    iers.earth_orientation_table.set(iers.IERS_A(Table.read(ROOT/'data/raw/iers_a_frozen.ecsv',format='ascii.ecsv')))
    z=np.load(ROOT/'data/raw/visibility_samples.npz')
    all_times=Time(z['midpoint_jd_utc'],format='jd',scale='utc')
    records=[(f'grid_{ra}_{dec}',ra,dec) for ra in range(0,360,30) for dec in [-21.15,-11.15,0,13.25,23.25]]
    records += [('M78',86.6908333333,.0791666667),('IC443',94.25,22.58),('CG4',113.5,-46.9)]
    names,ra,dec=map(np.asarray,zip(*records));ra=ra.astype(float);dec=dec.astype(float)
    coords=SkyCoord(ra[:,None]*u.deg,dec[:,None]*u.deg,frame='icrs')
    rows=[];angular=[]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        for month in MONTHS:
            valid={s:z[s+'_valid']&np.char.startswith(z[s+'_night'],month) for s in SITES}
            ii=np.flatnonzero(valid['gansu']|valid['asv']);times=all_times[ii]
            era=times.earth_rotation_angle('tio').rad
            theta={s:(era+np.deg2rad(lon))%(2*np.pi) for s,(lat,lon) in SITES.items()}
            a,d=apparent_directions(ra,dec,month);exact={}
            for site,(lat,lon) in SITES.items():
                location=EarthLocation.from_geodetic(lon*u.deg,lat*u.deg,0*u.m)
                frame=AltAz(obstime=times,location=location,pressure=0*u.hPa)
                exact[site]=coords.transform_to(frame).alt.deg
                approx=np.arcsin(np.sin(np.deg2rad(lat))*np.sin(d[:,None])+np.cos(np.deg2rad(lat))*np.cos(d[:,None])*np.cos(theta[site][None,:]-a[:,None]))
                angular.append(float(np.max(np.abs(np.rad2deg(approx)-exact[site]))))
            for moon in [False,True]:
                allowed={s:valid[s][ii]&(z[s+'_sun_alt_deg'][ii]< -18) for s in SITES}
                if moon:
                    for s in SITES:allowed[s]&=z[s+'_moon_alt_deg'][ii]<0
                allowed['simultaneous']=allowed['gansu']&allowed['asv']
                ordered={s:np.sort(theta['asv' if s=='asv' else 'gansu'][m]) for s,m in allowed.items()}
                for height in [30,40]:
                    computed=monthly_counts(a,d,ordered,height)
                    masks={s:allowed[s][None,:]&(exact[s]>=height) for s in SITES}
                    masks['simultaneous']=masks['gansu']&masks['asv']
                    for s in masks:
                        truth=masks[s].sum(axis=1)/12
                        for k,name in enumerate(names):
                            got=int(computed[s][k])/12
                            rows.append(dict(id=name,ra_deg=ra[k],dec_deg=dec[k],month=month,height=height,
                                             moon=moon,site=s,hours=float(truth[k]),atlas_hours=got,
                                             difference_minutes=(got-truth[k])*60))
            print(month,'full AltAz validation complete',flush=True)
    frame=pd.DataFrame(rows);frame.to_csv(ROOT/'tables/atlas_vs_full_altaz.csv',index=False)
    maximum=float(frame.difference_minutes.abs().max())
    assert maximum<=10.0001,maximum
    # Full maps must retain nesting/intersection identities at every sky pixel.
    cube=np.load(ROOT/'data/monthly_sky_counts.npz')['counts']
    assert cube.shape==(12,2,2,3,240,1440)
    assert np.all(cube[:,:,:,2]<=np.minimum(cube[:,:,:,0],cube[:,:,:,1]))
    assert np.all(cube[:,1]<=cube[:,0]) and np.all(cube[:,:,1]<=cube[:,:,0])
    browser=frame[np.abs(frame.dec_deg)<=30].to_dict('records')
    (ROOT/'tables/browser_reference.json').write_text(json.dumps(browser,separators=(',',':')))
    facts={'validation_cases':len(frame),'synthetic_and_real_directions':len(names),
           'months_validated':12,'max_duration_difference_minutes':maximum,
           'max_monthly_direction_altitude_difference_deg':max(angular),
           'threshold_and_moon_nesting':True,'true_intersection_bounded_by_both_sites':True,
           'method':'Full time-dependent topocentric Astropy AltAz at every five-minute cell'}
    (ROOT/'data/annual_validation.json').write_text(json.dumps(facts,indent=2));print(facts,flush=True)


if __name__=='__main__':main()

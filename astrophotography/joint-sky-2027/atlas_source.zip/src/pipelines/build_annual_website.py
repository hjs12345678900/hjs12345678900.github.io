"""Package the annual atlas into the existing site without replacing Q1 data.

The previous page is a presentation template only. All twelve-month scientific
arrays, DST-aware model, figures and validation evidence come from this run.
"""
from argparse import ArgumentParser
from pathlib import Path
import gzip,hashlib,json,re,shutil,zipfile
ROOT=Path(__file__).resolve().parents[2]


def page_document(template,validation):
    """Replace Q1 labels/controls/bootstrap while preserving the proven layout."""
    page=template.replace('2027 Q1','2027 全年').replace('2027年1—3月','2027年1—12月')
    options=''.join(f'<option value="2027-{m:02}">2027年{m}月</option>' for m in range(1,13))
    page=re.sub(r'(<select id="month">).*?(</select>)',lambda m:m[1]+options+m[2],page,flags=re.S)
    page=page.replace('三个月总览','全年十二个月总览').replace('36层时长WCS FITS','144层时长WCS FITS')
    page=page.replace('全季视图','全年视图')
    page=page.replace('ASV使用AEDT/UTC+11','ASV按日期使用AEDT/UTC+11或AEST/UTC+10')
    page=page.replace('与原47目标1692项完整AltAz结果最大差一个时间格。',
                      f"全年{validation['validation_cases']}项完整AltAz对照，最大时长差{validation['max_duration_difference_minutes']:.1f}分钟。")
    links=''.join(f'<a href="figures/2027_{m:02}_dss_mask.png">{m}月大图</a>' for m in range(1,13))
    page=re.sub(r'(<div class="links">)<a href="figures/2027_01_dss_mask.png">.*?</div>',lambda m:m[1]+links+'</div>',page,count=1,flags=re.S)
    page=re.sub(r'(<script id="sky-data" type="application/json">).*?(</script>)',r'\1\2',page,count=1,flags=re.S)
    old='<script src="assets/sky_model.js"></script><script src="assets/atlas_view_red.js"></script>\n<script src="assets/aladin.browser.js"></script><script>window.initDSSAtlas();</script>'
    assert old in page
    page=page.replace(old,'<script src="assets/load_atlas.js"></script>')
    page=page.replace('2027年1月至3月真实DSS2 Red月度共同天区总览','2027年全年真实DSS2 Red月度共同天区总览')
    page=page.replace('border:1px solid #393345;border-radius:8px','outline:1px solid #393345;border-radius:8px')
    return page


def sources_document(template,validation,ephemeris):
    """Update scientific descriptions using this run's measured validation."""
    text=template.replace('2027年1月1日至3月31日','2027年1月1日至12月31日').replace('版本 1.2.0','版本 2.0.0')
    text=text.replace('本季度 AEDT / UTC+11','按日期使用 AEDT / UTC+11 或 AEST / UTC+10')
    text=text.replace('3月31日晚包含4月1日凌晨。','12月31日晚包含2028年1月1日凌晨。2027年4月4日结束夏令时、10月3日开始夏令时；窗口起止分别标出当时实际偏移。')
    text=text.replace('与原47个目标、36种条件的完整 Astropy AltAz 结果对照共1692项，最大差约一个5分钟时间格。',
                      f"全年{validation['synthetic_and_real_directions']}个合成/真实方向，覆盖全部赤经与共同高度边界；与完整 Astropy AltAz 对照共{validation['validation_cases']}项，最大时长差{validation['max_duration_difference_minutes']:.1f}分钟。")
    text=text.replace('36层小时图','144层小时图').replace('全年Q1','全年')
    text=text.replace('data/calculation_metadata.json','data/calculation_metadata.json')
    note=f"<p>全年日月高度与时区记录：<a href=\"data/ephemeris_metadata.json\">计算元数据</a>；<a href=\"data/annual_validation.json\">十二个月数值核验</a>。"
    if ephemeris['outside_iers_prediction_cells']:
        note+='本次下载的IERS预测表覆盖至2027年11月5日；之后使用Astropy的表边界UT1及缺省极移，相关警告保存在元数据中。远期结果用于分钟级选题，不作秒级指向或时刻预报。'
    note+='</p>'
    text=text.replace('<h2>相机框与手动角度</h2>',note+'<h2>相机框与手动角度</h2>')
    text=text.replace('重新生成全部原始星历需要原项目的站点/时格生成流程及冻结 IERS 数据。','归档包含全年原始日月高度、IERS冻结表和全部计算/显示脚本；README给出从零计算和复用缓存两条复算路径。')
    text=text.replace('</main>', '<p><a href="../joint-sky-2027-q1/quarter-archive.html">原Q1历史快照</a></p></main>')
    text=text.replace('<main>', '<main><h1>v2.1 通用双站交互模型</h1><p>可设置任意两个地点的经纬度、IANA 时区与独立最低高度角 0–90°；默认甘肃 / ASV、30°。海拔为 0 m。通用模型支持全天区，采用五分钟地固日月位置、WGS84 站心视差和月中 CIRS 方向。日期按各站当地中午划分晚上。</p><p>72 个独立参考案例、216 项时长比较，抽样最大差 15 分钟，发生在上中天恰好擦过高度门槛的案例；其余案例按 10 分钟容差核对。此抽样不是所有地点的误差上限。<a href="data/general_validation.json">通用模型验证</a>。静态图、面积表与 FITS 仍对应默认站点。以下保留默认模型的原始计算说明，旧误差与天区范围只适用于旧模型。</p>')
    return text


def main():
    p=ArgumentParser();p.add_argument('site',type=Path);args=p.parse_args();site=args.site.resolve()
    old=site/'astrophotography/joint-sky-2027-q1';out=site/'astrophotography/joint-sky-2027'
    out.mkdir(exist_ok=True)
    for d in ['assets','data','figures','tables']:(out/d).mkdir(exist_ok=True)
    validation=json.loads((ROOT/'data/annual_validation.json').read_text())
    ephemeris=json.loads((ROOT/'data/ephemeris_metadata.json').read_text())
    template_path=old/'quarter-archive.html' if (old/'quarter-archive.html').exists() else old/'index.html'
    template=template_path.read_text()
    (out/'index.html').write_text((ROOT/'assets/atlas_page.html').read_text())
    (out/'sources.html').write_text(sources_document((old/'sources.html').read_text(),validation,ephemeris))
    for path in (ROOT/'assets').glob('*'):
        if path.is_file() and path.suffix in ['.js','.jpg','.json']:shutil.copy2(path,out/'assets'/path.name)
    for folder,pattern in [('data','*.json'),('figures','*.png'),('tables','*.csv')]:
        for path in (ROOT/folder).glob(pattern):shutil.copy2(path,out/folder/path.name)
    with gzip.open(out/'data/monthly_sky_hours_wcs.fits.gz','wb',compresslevel=6) as dest:
        with (ROOT/'data/monthly_sky_hours_wcs.fits').open('rb') as source:shutil.copyfileobj(source,dest)
    with zipfile.ZipFile(out/'atlas_source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        paths=[ROOT/'README.md',ROOT/'requirements.txt',ROOT/'config.json',ROOT/'VERSION']
        for folder,pattern in [('src','*.py'),('src','*.cjs'),('src','*.js'),('assets','*.js'),('assets','*.html'),('data','*.json'),('tables','*.csv'),('tables','*.json'),('data','*.npz'),('runs','*.json'),('docs','*.md')]:
            paths+=list((ROOT/folder).rglob(pattern))
        paths += [ROOT/'data/raw/iers_a_frozen.ecsv',ROOT/'data/raw/dss2_red_allsky.jpg',ROOT/'data/raw/dss2_red_properties.txt',ROOT/'assets/dss2_red_car_preview.jpg',ROOT/'assets/dss2_red_car_display.jpg']
        for path in sorted(set(paths)):archive.write(path,path.relative_to(ROOT))
    manifest={'version':(ROOT/'VERSION').read_text().strip(),'page':'/astrophotography/joint-sky-2027/',
              'months':12,'layers':144,'model_sha256':hashlib.sha256((ROOT/'data/point_model.json').read_bytes()).hexdigest(),'files':[]}
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='release_manifest.json':manifest['files'].append({'path':str(path.relative_to(out)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (out/'release_manifest.json').write_text(json.dumps(manifest,indent=2))
    # Keep the immutable Q1 page readable; its old entry forwards to the update.
    if not (old/'quarter-archive.html').exists():shutil.copy2(old/'index.html',old/'quarter-archive.html')
    (old/'index.html').write_text('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=../joint-sky-2027/"><title>2027全年双站星图</title><link rel="canonical" href="https://hjs12345678900.github.io/astrophotography/joint-sky-2027/"></head><body><p>已更新为<a href="../joint-sky-2027/">2027全年星图</a>。<a href="quarter-archive.html">原Q1快照</a></p></body></html>')
    home=site/'astrophotography/index.html';page=home.read_text().replace('/astrophotography/joint-sky-2027-q1/','/astrophotography/joint-sky-2027/').replace('2027 Q1 · interactive sky atlas','2027 · full-year interactive sky atlas').replace('January · February · March 2027','January–December 2027');home.write_text(page)
    print('Annual website built:',out,flush=True)


if __name__=='__main__':main()

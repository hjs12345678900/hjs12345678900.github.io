"""Cache location-independent Earth-fixed Sun/Moon positions for browser planning.

Positions are geocentric ITRS kilometres at five-minute UTC midpoints. Browser
subtraction of a WGS84 observer includes lunar parallax; refraction is disabled.
The monthly CIRS Cartesian grids avoid RA interpolation singularities at poles.
"""
from pathlib import Path
import sys,json,base64
import numpy as np
import astropy.units as u
from astropy.coordinates import get_sun,get_body,ITRS
from astropy.time import Time
from astropy.table import Table
from astropy.utils import iers
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/scientific_core'))
from monthly_sky_geometry import apparent_directions,MONTHS

def encode(a):
    """Encode row-major float32 arrays, with units specified by payload keys."""
    return base64.b64encode(np.asarray(a,dtype='<f4').tobytes()).decode()

def main():
    iers.conf.auto_download=False
    iers.conf.auto_max_age=None
    iers.conf.iers_degraded_accuracy="warn"

    iers.earth_orientation_table.set(iers.IERS_A(Table.read(ROOT/'data/raw/iers_a_frozen.ecsv',format='ascii.ecsv')))
    first=Time('2026-12-31T00:00:00').unix
    end=Time('2028-01-03T00:00:00').unix
    t=Time(np.arange(first+150,end,300),format='unix')
    data={'first_edge_unix':first,'step_seconds':300,'era':encode(t.earth_rotation_angle('tio').rad),'cirs':{}}
    for name,body in [('sun',get_sun(t)),('moon',get_body('moon',t))]:
        data[name+'_itrs_km']=encode(body.transform_to(ITRS(obstime=t)).cartesian.xyz.to_value(u.km).T)
    rr,dd=np.meshgrid(np.arange(360),np.arange(-90,91))
    for month in MONTHS:
        a,d=apparent_directions(rr,dd,month)
        data['cirs'][month]=encode(np.stack([np.cos(d)*np.cos(a),np.cos(d)*np.sin(a),np.sin(d)],axis=-1))
    (ROOT/'data/general_ephemeris.json').write_text(json.dumps(data,separators=(',',':')))
    print('Wrote general ephemeris:',len(t),'cells')
if __name__=='__main__':main()

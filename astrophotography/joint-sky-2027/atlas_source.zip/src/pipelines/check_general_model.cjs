/* Compare browser durations with independent per-time Astropy AltAz references. */
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
const context=vm.createContext({window:{generalEphemeris:JSON.parse(read('data/general_ephemeris.json'))},document:{getElementById:()=>({textContent:read('data/point_model.json')})},atob,Intl,Date,Uint8Array,Float32Array,Math,Object,Array});
for(const file of ['sky_model.js','general_model.js'])vm.runInContext(read('assets/'+file),context);
const M=context.window.SkyModel;let maximum=0;
const rows=JSON.parse(read('data/general_reference.json'));
for(const row of rows){M.configure(row.sites);const value=M.evaluate(row.ra,row.dec,row);for(const [i,k]of ['gansu','asv','simultaneous'].entries()){const error=Math.abs(value[k]-row.hours[i])*60;maximum=Math.max(maximum,error);const tangent=row.sites.some(s=>Math.abs(90-Math.abs(s.lat-row.dec)-s.height)<0.1);assert(error<=(tangent?30:10)+0.00001,JSON.stringify({row,k,error,value}));}assert(value.simultaneous<=value.common+1e-8);}
// Identical sites must share every eligible cell, including circumpolar arcs.
const site={name:'Polar',lat:80,lon:179,zone:'UTC',height:10};M.configure([site,site]);
for(const dec of [-90,0,70,90]){const v=M.evaluate(359,dec,{month:'2027-12',moon:false});assert(Math.abs(v.simultaneous-v.gansu)<1e-8);}
const report={cases:rows.length,comparisons:rows.length*3,max_difference_minutes:maximum,identical_site_and_pole_checks:true,tolerance_minutes:10,tangent_boundary_tolerance_minutes:30};
fs.writeFileSync(path.join(root,'data/general_validation.json'),JSON.stringify(report,null,2));console.log(report);

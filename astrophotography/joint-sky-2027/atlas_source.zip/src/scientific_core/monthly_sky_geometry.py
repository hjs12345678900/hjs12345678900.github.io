"""Evaluate full-sky visibility using Astropy CIRS and Earth rotation angles.

All Sun/Moon selections use the previous exact 5-minute Astropy calculation.
ICRS directions are transformed to geocentric CIRS at each month's midpoint;
this slowly varying mapping is frozen only within that month. The rotating
horizon is evaluated at every original time cell, not a representative night.
"""
import numpy as np
import astropy.units as u
from astropy.coordinates import CIRS, SkyCoord
from astropy.time import Time

SITES={'gansu':(38.826387,103.3294496),'asv':(-36.727973,143.269703)}
MONTHS=[f'2027-{month:02}' for month in range(1,13)]


def apparent_directions(ra_deg,dec_deg,month):
    """Return CIRS RA and declination in radians for broadcast ICRS degree arrays.

    The adopted epoch is the 16th at 00 UTC; apparent annual aberration and
    precession/nutation come from Astropy. Residual within-month changes are
    validated against the original full AltAz calculation, not assumed zero.
    """
    c=SkyCoord(np.asarray(ra_deg)*u.deg,np.asarray(dec_deg)*u.deg,frame='icrs')
    a=c.transform_to(CIRS(obstime=Time(month+'-16T00:00:00',scale='utc')))
    return a.ra.rad,a.dec.rad


def hour_angle_limit(dec_rad,latitude_deg,altitude_deg):
    """Return horizon half-width in hour angle radians; zero means inaccessible.

    sin(h)=sin(phi)sin(delta)+cos(phi)cos(delta)cos(H), with h the altitude,
    phi geodetic latitude and delta CIRS declination. Polar motion and diurnal
    aberration are omitted at sub-arcsecond scale; refraction is disabled.
    """
    phi=np.deg2rad(latitude_deg)
    q=(np.sin(np.deg2rad(altitude_deg))-np.sin(phi)*np.sin(dec_rad))/(np.cos(phi)*np.cos(dec_rad))
    return np.arccos(np.clip(q,-1,1))


def circular_count(sorted_theta,low,high):
    """Count sorted [0,2pi) meridians in broadcast closed circular intervals.

    low/high are radians and may cross the origin. Empty intervals high<=low
    return zero. Input arrays are not mutated. Returns int64 cell counts.
    """
    low,high=np.broadcast_arrays(low,high)
    length=high-low;lo=low%(2*np.pi);hi=lo+np.maximum(length,0)
    n=len(sorted_theta)
    straight=np.searchsorted(sorted_theta,np.minimum(hi,2*np.pi),side='right')-np.searchsorted(sorted_theta,lo,side='left')
    wrap=np.where(hi>2*np.pi,np.searchsorted(sorted_theta,hi-2*np.pi,side='right'),0)
    return np.where(length<=0,0,np.where(length>=2*np.pi,n,straight+wrap))


def monthly_counts(ra_cirs,dec_cirs,theta_sorted,altitude_deg):
    """Return gansu/asv/true-simultaneous cell counts for CIRS directions.

    theta_sorted contains site-selected sorted local-meridian arrays; the
    simultaneous array is expressed in Gansu's meridian system and already
    requires both sites' darkness/Moon selections at identical UTC cells.
    """
    hg=hour_angle_limit(dec_cirs,SITES['gansu'][0],altitude_deg)
    ha=hour_angle_limit(dec_cirs,SITES['asv'][0],altitude_deg)
    delta=np.deg2rad(SITES['asv'][1]-SITES['gansu'][1])
    result={s:circular_count(theta_sorted[s],ra_cirs-h,ra_cirs+h)
            for s,h in [('gansu',hg),('asv',ha)]}
    low=ra_cirs+np.maximum(-hg,-delta-ha)
    high=ra_cirs+np.minimum(hg,-delta+ha)
    result['simultaneous']=circular_count(theta_sorted['simultaneous'],low,high)
    return result

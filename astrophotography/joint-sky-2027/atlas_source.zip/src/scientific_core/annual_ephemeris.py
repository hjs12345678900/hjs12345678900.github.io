"""Calculate exact five-minute solar/lunar horizon constraints for a full year.

Astropy ICRS/AltAz transforms use the built-in ephemeris, zero refraction and
zero site elevation. ZoneInfo converts every UTC sample individually; UTC
offsets are never assumed constant across the Melbourne DST transitions.
"""
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import astropy.units as u
import numpy as np
from astropy.coordinates import AltAz, EarthLocation, get_body, get_sun
from astropy.time import Time


def time_grid(year, step_seconds=300):
    """Return float64 Unix cell edges (N+1,) and UTC midpoint Time (N,).

    The envelope covers all local noon-to-noon nights labelled in ``year`` at
    the supplied Gansu/Melbourne sites, including December 31 after midnight.
    A step must divide 3600 seconds; these are geometric integration cells.
    """
    if step_seconds <= 0 or 3600 % step_seconds:
        raise ValueError('Cadence must divide 3600 seconds.')
    first = datetime(year,1,1,tzinfo=timezone.utc).timestamp()
    last = datetime(year+1,1,1,4,tzinfo=timezone.utc).timestamp()
    edges = np.arange(first,last+step_seconds,step_seconds,dtype=np.float64)
    return edges,Time((edges[:-1]+edges[1:])/2,format='unix',scale='utc')


def evening_labels(times, zone, year):
    """Return local-evening YYYY-MM-DD strings, valid-year bool and hour offsets.

    Inputs are UTC Time (N,), IANA zone string and integer calendar year.
    Labels use local wall-clock noon as the date boundary; both occurrences
    of a repeated autumn hour retain the same evening date. Offset is sampled
    at each instant, including any 23/25-hour civil day.
    """
    local = times.to_datetime(timezone=ZoneInfo(zone))
    labels = np.array([(t-timedelta(hours=12)).strftime('%Y-%m-%d') for t in local])
    valid = (labels>=f'{year}-01-01')&(labels<=f'{year}-12-31')
    offsets = np.array([t.utcoffset().total_seconds()/3600 for t in local])
    return labels,valid,offsets


def sun_moon_altitudes(times, latitude, longitude):
    """Return Sun and Moon-centre geometric AltAz altitude arrays (N,), degrees.

    Latitude/longitude are geodetic degrees, positive north/east. Moon uses
    the observer location in both its ephemeris and horizon transformation.
    This is neither a sky-brightness estimate nor a terrain-horizon model.
    """
    location=EarthLocation.from_geodetic(longitude*u.deg,latitude*u.deg,0*u.m)
    frame=AltAz(obstime=times,location=location,pressure=0*u.hPa)
    sun=get_sun(times).transform_to(frame).alt.deg
    moon=get_body('moon',times,location=location).transform_to(frame).alt.deg
    return sun,moon

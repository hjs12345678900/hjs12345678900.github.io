# 通用双站共同天区 · 2027

版本 2.1.0。交互页面支持任意两个地点的名称、经纬度、IANA 时区，以及各自 0–90° 的目标最低高度角（可输入小数）。默认甘肃与 ASV、各 30°。海拔仍为 0 m，不含地形与折射。

点击“应用地点与高度”后重新计算。日期依各站当地中午划分晚上，真正同时条件要求同一 UTC 格同时满足各站所选月份。CSV 保存每条候选当时的完整地点参数。输入错误保留之前的已应用参数。

通用模型覆盖 Dec −90°…+90°；在线 DSS 支持全天，离线摄影预览仍只覆盖 −30°…+30°。静态 PNG、面积表和 144 层 FITS 是默认地点的历史预计算结果，不随页面参数更新。

新增流程（依赖与冻结 IERS 沿用下文）：

```sh
python3 src/pipelines/build_general_ephemeris.py
python3 src/pipelines/validate_general_model.py
node src/pipelines/check_general_model.cjs
python3 src/pipelines/build_annual_website.py /absolute/path/to/website
```

`general_ephemeris.json` 保存五分钟地固日月位置（km）、地球自转角（rad）与每月 CIRS 单位向量网格。浏览器用 WGS84 站点位置减去地心向量，纳入月球视差，再按当地夜晚筛选。目标用月中 CIRS 方向近似。时间包络扩至 2026-12-31—2028-01-03 UTC，覆盖全球时区年末夜晚。极区和跨经度 ±180° 的同时区间以圆周交集合并计算。

独立验证见 `data/general_validation.json`，参考计算使用完整逐时格 Astropy AltAz，覆盖默认双站、日期变更线两侧和极地，1/6/12 月、不同高度与月光条件。结果只描述这组抽样，不是所有坐标的误差保证。冻结 IERS 越界限制仍适用。

以下是 v2.0 默认站点预计算结果的历史说明。

# 2027 全年甘肃 × ASV：DSS2 Red 共同天区

版本2.0.0。[公开星图](https://hjs12345678900.github.io/astrophotography/joint-sky-2027/)覆盖2027年1月1日至12月31日当地晚上，包括12月31日跨入2028年凌晨的窗口。旧Q1入口自动转到全年版，原图表与[Q1快照](https://hjs12345678900.github.io/astrophotography/joint-sky-2027-q1/quarter-archive.html)保留。

选择月份、30°/40°最低高度、月亮落下条件和月时长门槛。亮区是两站各自都够时长的天区；切换“真正同时”才要求同一UTC时刻。点击任意天区查看两站各自小时、工时之和、同时小时、最长窗口与实际当地时间。三个相机框表达天球角覆盖，可转90°；候选可导出CSV。选点仅存于当前页面，关闭前导出。

## 天文计算与时间

- 甘肃：+38.826387°、+103.3294496°，Asia/Shanghai。ASV：−36.727973°、+143.269703°，Australia/Melbourne。
- 全年105,168个五分钟中点UTC时格，完整覆盖两站当地中午至次日中午归属的365个晚上。UTC偏移逐时刻用IANA时区计算；ASV在4月4日从UTC+11变为UTC+10，10月3日恢复UTC+11。浏览器使用同一IANA规则显示起止时间，跨夏令时的窗口两端分别标注偏移。
- Astropy 7.2.0，内置日月星历，地形未知，海拔0米，折射关闭。太阳中心高度<−18°，目标≥30°或40°，可选月球中心高度<0。月下条件不是完整天空背景模型。
- RA 0–360°、Dec −30°至+30°，0.25°地图网格。12个月×2高度×2月光×3站点定义，144个时长图层。
- ICRS→CIRS方向固定在每月16日；完整五分钟地球自转与日月高度均逐时格计算。点击点的方向修正采用1°网格双线性插值。不是只用月中一晚。
- `annual_validation.json`及CSV记录与全年完整时变、站心Astropy AltAz的独立比较；合成方向覆盖全部赤经及共同高度边界，另含M78/IC443。误差采用实际对照值，勿将很多小数理解为秒级精度。
- IERS官方表从https://datacenter.iers.org/data/9/finals2000A.all 下载并冻结。当前表到2027年11月5日；后续时段使用Astropy表边界UT1与缺省极移，元数据记录越界时格数和所有警告。远期规划用于分钟级选题，观测前可用新IERS表复算。
- 所有时长为几何上限，未扣天气、地形、透明度或设备开销。各目标争用同一夜晚，不能相加为可实现整季工时；大视场四角可能比中心低。

## 真实巡天与设备

DSS2 Red (F+R)是真实摄影红波段，不是Hα窄带。原始资料由STScI/NASA与原摄影巡天机构提供，CDS完成HiPS编码。高清使用[China-VO镜像](https://hips.china-vo.org/m/DSS2Merged/)，CDS两站备用；内置约7′采样的预览来自[IRSA](https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/red/)。沿用已用四幅独立DSS FITS校验过的ICRS CAR预览及原始哈希；没有生成、补画或用漂亮照片猜比例。

- A：150PDS，750mm，3856×2180有效像素，2.9μm；约51.26′×28.98′，0.798″/px。
- B：RC10 0.8×，1600mm，6252×4176有效像素，3.76μm；约50.51′×33.74′，0.485″/px。
- C：SQA55，264mm，同款MiniCam8；约145.59′×82.32′，2.266″/px。

框线用天球切平面反投影；Bin2不改变全幅视场，ROI才改变。长边东西向指天球方向；相机相对调焦座的机械角度应通过试拍板解确认。视场相近不代表分辨率或暗结构能力相同。

## 可复运行流程

依赖见`requirements.txt`；不需要为浏览网页安装Python。用独立Python环境安装后，在本目录执行：

```sh
python3 src/pipelines/calculate_annual_ephemeris.py
python3 src/pipelines/calculate_monthly_sky.py
python3 src/pipelines/validate_annual_model.py
python3 src/visualization/render_monthly_dss_masks.py
python3 src/pipelines/build_annual_website.py /absolute/path/to/website
```

复用缓存时跳过第一步。`config.json`、冻结IERS表和日月时序随源码归档；下载FITS是全部144层时长图。真实预览已作为资产缓存，不必重新联网投影；巡天方向核验记录在`data/red_reprojection_validation.json`。网站只静态提供已计算数据，高清瓦片按需读取公共镜像，没有本地服务依赖。

四个职责区域：`scientific_core`为日月/时间与天球积分；`pipelines`为计算、独立核验及网站打包；`visualization`绘制真实巡天遮罩；`assets`为浏览器模型/显示和原厂Aladin模块。浏览器和Python独立比较见`output/playwright`与`data`。运行输入、哈希与版本在`runs/annual_2027_run001`。

Aladin Lite 3.9.2-beta为LGPL-3.0-or-later，未改动发行模块保留于`assets/aladin.js`，浏览器包装仅替换末尾export；[上游源码与授权](https://github.com/cds-astro/aladin-lite)。

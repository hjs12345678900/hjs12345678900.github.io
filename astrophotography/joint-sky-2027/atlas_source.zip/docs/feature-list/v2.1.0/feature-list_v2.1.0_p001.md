# v2.1.0

- FEAT-0021：任意双站、独立高度角、全球时区、全天区、圆周重合与参数 CSV。独立验证见 data/general_validation.json；默认静态资产保持标注。

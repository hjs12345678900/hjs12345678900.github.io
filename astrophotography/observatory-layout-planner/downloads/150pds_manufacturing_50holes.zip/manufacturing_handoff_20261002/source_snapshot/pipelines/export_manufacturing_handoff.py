"""Package unchanged CAD with explicit clearance/tapped-hole manufacturing layers."""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import sys
import cadquery as cq
import ezdxf

ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'))
from scientific_core.build_full_pattern_adapter import full_pattern_rows
SOURCE=ROOT/'runs/all_detent_holes_20261002'
OUT=ROOT/'runs/manufacturing_handoff_20261002'


def run():
    """Re-export one plate/strip, preserve assembly tree, audit the 50-hole data."""
    (OUT/'cad').mkdir(parents=True,exist_ok=True);(OUT/'output/pdf').mkdir(parents=True,exist_ok=True)
    shutil.copy2(SOURCE/'parameters.json',OUT/'parameters.json')
    p=json.loads((OUT/'parameters.json').read_text());rows=full_pattern_rows(p)
    names=[('adapter_all_detents_50holes_REVIEW.step','adapter_600x120x12_50holes_TAP_PILOTS.step',50),
           ('shared_two_hole_strip_REVIEW.step','shared_two_hole_strip.step',2)]
    checks={}
    for old,new,count in names:
        shape=cq.importers.importStep(str(SOURCE/'cad'/old))
        assert len(shape.solids().vals())==1 and shape.val().isValid()
        assert len(shape.faces('%CYLINDER').vals())==count if count==50 else True
        cq.exporters.export(shape,str(OUT/'cad'/new))
        restored=cq.importers.importStep(str(OUT/'cad'/new))
        assert restored.val().isValid() and abs(restored.val().Volume()-shape.val().Volume())<1e-5
        box=restored.val().BoundingBox()
        checks[new]=dict(solids=1,valid=True,volume_mm3=restored.val().Volume(),bbox_mm=[box.xlen,box.ylen,box.zlen])
    assembly='assembly_L16_R16_55parts.step'
    shutil.copy2(SOURCE/'cad/assembly_L16_R16_REVIEW.step',OUT/'cad'/assembly)
    shape=cq.importers.importStep(str(OUT/'cad'/assembly))
    assert len(shape.solids().vals())==55 and all(s.isValid() for s in shape.solids().vals())
    checks[assembly]=dict(solids=55,valid=True,source_preserved_byte_for_byte=True)
    doc=ezdxf.new('R2010');doc.units=ezdxf.units.MM;model=doc.modelspace()
    for name,color in [('OUTLINE',7),('A_D6P5_THROUGH_NO_THREAD',5),('B_M6X1_6H_TAP_D5_PILOT',3),('NOTES_NO_CUT',7)]:
        doc.layers.new(name,dxfattribs={'color':color})
    model.add_lwpolyline([(-300,-60),(300,-60),(300,60),(-300,60)],close=True,dxfattribs={'layer':'OUTLINE'})
    schedule=[]
    for i,r in enumerate(rows,1):
        tapped=r['kind']=='TAP';layer='B_M6X1_6H_TAP_D5_PILOT' if tapped else 'A_D6P5_THROUGH_NO_THREAD'
        model.add_circle((r['x'],r['y']),r['d']/2,dxfattribs={'layer':layer})
        schedule.append(dict(id=r['id'],x_centre_mm=r['x'],y_centre_mm=r['y'],
                             x_from_left_mm=r['x']+300,y_from_bottom_mm=r['y']+60,
                             finished_feature='M6x1-6H THRU' if tapped else 'D6.5 +0.10/0 THRU',
                             drill_diameter_mm=r['d'],threaded='YES' if tapped else 'NO',
                             through_plate='YES',source_status='MATING DIMENSIONS REQUIRE PHYSICAL CHECK'))
    notes=['ADP-050 REV A / 600 x 120 x 12 mm / 50 HOLES',
           'A: 8 x DIA6.5 +0.10/0 THRU, NO THREAD.',
           'B: 42 x M6x1-6H THRU; circles show DIA5.0 CUT-TAP PILOTS, NOT clearance holes.',
           '42 B holes MUST be tapped. Drawing PDF governs threads and tolerances.',
           'ORIGIN: plate centre; bottom left is (-300,-60). All geometry in mm.',
           'HOLD: lower inner X=+/-78.783232 and outer Y=+/-27.8 estimated; verify mating parts.',
           'Full 0/16/32 mm detent patterns already present. Do not remove alternate holes.']
    model.add_mtext('\n'.join(notes),dxfattribs={'layer':'NOTES_NO_CUT','insert':(-300,-80),'char_height':4,'width':600})
    path=OUT/'cad/adapter_50holes_drill_and_tap.dxf';doc.saveas(path)
    restored=ezdxf.readfile(path);assert not restored.audit().has_errors
    circles=list(restored.modelspace().query('CIRCLE'));assert len(circles)==50
    assert sum(c.dxf.layer=='A_D6P5_THROUGH_NO_THREAD' for c in circles)==8
    assert sum(c.dxf.layer=='B_M6X1_6H_TAP_D5_PILOT' for c in circles)==42
    with (OUT/'hole_schedule_drill_and_tap.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(schedule[0]));writer.writeheader();writer.writerows(schedule)
    checks['hole_counts']=dict(total=50,clearance_D6p5=8,tapped_M6x1=42)
    checks['DXF_audit']='passed';checks['source_geometry_changed']=False
    checks['conditional_manufacturing_hold']=['unmeasured mating coordinates','strip material and practical fastener fit']
    (OUT/'export_checks.json').write_text(json.dumps(checks,indent=2))
    print(json.dumps(checks,indent=2))


if __name__=='__main__':run()

"""Dimension the unchanged 50-hole adapter and its separate bearing strip.

This manufacturing handoff specifies nominal geometry and proposed process
requirements. Unmeasured mating dimensions remain explicit HOLD items.
"""
from pathlib import Path
import json
import sys
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A3,A4,landscape

ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'))
from scientific_core.build_full_pattern_adapter import full_pattern_rows
from visualization.machining_drawing_primitives import Draft,INK,BLUE,GREEN,ORANGE,PURPLE
OUT=ROOT/'runs/manufacturing_handoff_20261002'


def adapter(rows):
    """Write one landscape A3 sheet, all 50 positions dimensioned by lines."""
    path=OUT/'output/pdf/adapter_50holes_machining_A3.pdf'
    c=canvas.Canvas(str(path),pagesize=landscape(A3));d=Draft(c)
    c.setTitle('转接板加工交底图：8×Ø6.5通孔 / 42×M6×1-6H通牙')
    d.text(30,810,'转接板加工交底图 | 600 × 120 × 12 | 三档共用 50 孔',21)
    d.text(30,789,'图号 ADP-050 · 修订 A · 名义模型不变 · 单位 mm · 不按打印比例量取尺寸',10)
    d.text(30,767,'A：8 × Ø6.5 通孔（不攻牙）',11,BLUE)
    d.text(360,767,'B：42 × M6×1-6H 通牙（切削攻丝底孔 Ø5.0 通）',11,GREEN)
    d.text(915,767,'* = 配合尺寸待实物复核',10,ORANGE)
    sc=1.55;cx=590;cy=498;X=lambda x:cx+x*sc;Y=lambda y:cy+y*sc
    d.rect(X(-300),Y(-60),600*sc,120*sc)
    c.setDash([6,3,1,3]);d.line(X(-310),Y(0),X(310),Y(0),'#9BA7B0',.4)
    d.line(X(0),Y(-68),X(0),Y(68),'#9BA7B0',.4);c.setDash()
    d.text(X(4),Y(64),'对称中心',8)
    for r in rows:
        col=BLUE if r['kind']=='CLEAR' else ORANGE if '16' in r['pattern'] else PURPLE if '32' in r['pattern'] else GREEN
        d.hole(X(r['x']),Y(r['y']),r['major'],sc,r['kind']=='TAP',col)
    d.dim(X(-300),X(300),735,'600 ±0.20',Y(60),10)
    xs=[-300,-254,-238,-222,0,222,238,254,300]
    for a,b in zip(xs,xs[1:]):d.dim(X(a),X(b),698,f'{b-a:g}',Y(27.8))
    d.text(35,699,'B 纵排定位',9)
    d.dim(X(-113.65),X(113.65),656,'227.30（关于中心对称）',Y(10),9)
    d.dim(X(-78.7832317),X(78.7832317),630,'157.566*（关于中心对称）',Y(10),9)
    d.text(35,645,'A 孔列定位',9,BLUE)
    d.vdim(X(-144),Y(-10),Y(10),'20',X(-113.65))
    d.vdim(X(307),Y(-60),Y(60),'120 ±0.10',X(300),9)
    d.vdim(X(287),Y(-27.8),Y(27.8),'55.60*',X(254))
    d.vdim(X(272),Y(-17.68),Y(17.68),'35.36',X(254))
    d.vdim(X(58),Y(-28.325),Y(28.325),'56.65',X(0))
    d.vdim(X(43),Y(-16.825),Y(16.825),'33.65',X(0))
    d.text(X(-71),Y(-49),'中排 B 孔',9,GREEN)
    d.leader(X(-113.65),Y(10),X(-133),Y(33),X(-173),Y(36),'A  8孔',BLUE)
    d.leader(X(-238),Y(27.8),X(-246),Y(45),X(-277),Y(48),'B  全部通牙',GREEN)
    # A complete transverse chain also locates the eight formerly omitted holes.
    xs=[-300]+sorted({r['x'] for r in rows if r['connection']=='round'})+[300]
    for a,b in zip(xs,xs[1:]):d.dim(X(a),X(b),364,f'{b-a:g}',Y(0),8)
    d.text(35,365,'B 横排定位',9)
    d.text(127,343,'横排全部位于 Y 中心线；其余各对孔排均关于 Y 中心线对称。',9)
    d.rect(X(-300),308,600*sc,12*sc)
    d.vdim(X(307),308,308+12*sc,'12 ±0.10',X(300),9)
    d.text(127,291,'侧视：所有 A 孔和 B 螺纹均贯通板厚；本板不设沉头、沉孔或凹槽。',10)
    d.line(30,276,1158,276,'#BCC6CE')
    notes=[
        '1  孔型以 A/B 标注为准：A=Ø6.5 +0.10/0 通孔；B=M6×1-6H 右旋通牙，共42处。不得将 B 加工成 Ø6 通孔。',
        '2  B 采用切削攻丝：名义底孔 Ø5.0 通，攻丝贯穿板厚；成品用 M6×1-6H 通止规检查。挤压丝锥须另定底孔。',
        '3  名义孔位取随附 STEP/DXF；图上链式尺寸用于读图，孔位按板中心统一定位，不能逐段累计公差。',
        '4  拟定加工要求：孔中心相对中心基准 X/Y 各 ±0.05；两接触面平面度 0.10、平行度 0.10，Ra 3.2。',
        '5  材料拟定 6061-T6 铝板；外缘轻倒钝 C0.2-0.3；孔口只去毛刺，不加大沉孔，不损伤螺纹有效牙。',
        '6  彩色仅区分外移档：绿=原位/中槽，橙=外移16，紫=外移32；三档 B 孔全部加工在同一块板上。',
        '7  * 项：底板内列 X=±78.783 与外槽 Y=±27.800 均含估测，须原件复核后定值；原件其余配合孔亦须核对。',
        '8  相邻 M6 最小中心距8、名义余料2；外槽相邻Ø10螺钉头名义间隙0.12，实测头径/孔距合格后再装配。',
        '9  STEP 的 B 孔为 Ø5 螺纹底孔几何，无真实螺旋牙；攻丝要求以本图为准。无表面处理要求，需处理时另核尺寸。']
    for i,s in enumerate(notes):d.text(32,256-i*18,s,9.5,ORANGE if i==6 else INK)
    d.line(30,80,1158,80,'#BCC6CE')
    d.text(32,61,'状态：可用于加工交底与报价；* 配合尺寸未实测，尚不能无条件投产。公差为本次拟定，非来源图公差。',10)
    d.text(32,39,'零件：转接板 · 数量 1 · 名义质量约 2.30 kg · 2026-10-02 · A3 / 单页',9)
    d.text(800,39,'装配按 L16/R16 参考；本板支持全部九组合。',9)
    c.showPage();c.save();return path


def strip():
    """Write a separate two-hole bearing-strip detail, quantity four."""
    path=OUT/'output/pdf/shared_strip_machining_A4.pdf'
    c=canvas.Canvas(str(path),pagesize=A4);d=Draft(c)
    c.setTitle('双孔压片：21.12×11×1.6，2×Ø6.4通孔')
    d.text(35,795,'双孔压片加工交底图',21)
    d.text(35,770,'图号 STR-002 · 修订 A · 数量 4 · 单位 mm',11)
    k=13;cx=275;cy=570;half=21.12*k/2
    c.roundRect(cx-half,cy-5.5*k,2*half,11*k,5.5*k,fill=0,stroke=1)
    for s in [-1,1]:d.hole(cx+s*5.06*k,cy,6.4,k,False,BLUE)
    d.dim(cx-half,cx+half,690,'21.12*',cy+5.5*k,11)
    d.dim(cx-5.06*k,cx+5.06*k,450,'10.12*',cy,11)
    d.vdim(cx+half+28,cy-5.5*k,cy+5.5*k,'11.00',cx+half,11)
    d.text(55,420,'2 × Ø6.4 +0.10/0 通孔；不攻牙；圆端 R5.5。',11,BLUE)
    d.rect(cx-half,370,2*half,1.6*k);d.vdim(cx+half+28,370,370+1.6*k,'1.60',cx+half,11)
    for i,s in enumerate([
        '钢制压片；具体钢材牌号/硬度待选，不沿用铝板材质。',
        '拟定：外形/厚度 ±0.05，孔中心相对对称中心 ±0.03。',
        '两面平整、去毛刺；不进行孔口大倒角，不减薄承压边。',
        '* 孔距随实测外槽螺孔间距确定；本图10.12为当前名义值。',
        '同长槽两螺钉头Ø10名义间隙仅0.12，需用实际件检查。',
        '材料、局部承压/弯曲及孔距未确认前，不作批量投产依据。']):d.text(35,321-i*26,s,10)
    d.text(35,105,'名义 STEP 单件已附；夹紧承载尚未验证。',10)
    d.text(35,68,'2026-10-02 · A4 / 单页 · STR-002',9)
    c.showPage();c.save();return path


def run():
    """Read the frozen current parameters and generate two separate drawings."""
    p=json.loads((OUT/'parameters.json').read_text());rows=full_pattern_rows(p)
    assert len(rows)==50 and sum(r['kind']=='TAP' for r in rows)==42
    print(adapter(rows));print(strip())


if __name__=='__main__':run()

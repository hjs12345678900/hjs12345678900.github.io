"""ReportLab drafting primitives, paper coordinates in points, labels in mm."""
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.colors import HexColor,white

pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
INK='#26384B';BLUE='#147DAD';GREEN='#20865F';ORANGE='#B36C18';PURPLE='#8858AA'


class Draft:
    """Draw explicit dimension lines and hole types without coordinate tables."""
    def __init__(self,canvas):self.c=canvas

    def text(self,x,y,s,size=9,color=INK):
        c=self.c;c.setFillColor(HexColor(color))
        for ch in s:
            font='Helvetica' if ord(ch)<256 else 'STSong-Light'
            c.setFont(font,size);c.drawString(x,y,ch);x+=pdfmetrics.stringWidth(ch,font,size)

    def line(self,x1,y1,x2,y2,color=INK,w=.6):
        self.c.setStrokeColor(HexColor(color));self.c.setLineWidth(w);self.c.line(x1,y1,x2,y2)

    def rect(self,x,y,w,h,color=INK):
        self.c.setStrokeColor(HexColor(color));self.c.setLineWidth(.7);self.c.rect(x,y,w,h,fill=0)

    def dim(self,x1,x2,y,label,base,size=8):
        for x in [x1,x2]:
            self.line(x,base,x,y+3,'#9BA7B0',.35);self.line(x-2,y-2,x+2,y+2)
        self.line(x1,y,x2,y);width=sum(pdfmetrics.stringWidth(ch,'Helvetica' if ord(ch)<256 else 'STSong-Light',size) for ch in label)
        self.c.setFillColor(white);self.c.rect((x1+x2-width)/2-1,y-1,width+2,size+2,fill=1,stroke=0)
        self.text((x1+x2-width)/2,y+1,label,size)

    def vdim(self,x,y1,y2,label,base,size=8):
        for y in [y1,y2]:
            self.line(base,y,x+3,y,'#9BA7B0',.35);self.line(x-2,y-2,x+2,y+2)
        self.line(x,y1,x,y2)
        self.c.saveState();self.c.translate(x-3,(y1+y2)/2-len(label)*size*.25);self.c.rotate(90)
        self.text(0,0,label,size);self.c.restoreState()

    def hole(self,x,y,major,scale,tapped,color):
        """Show tapped holes by a full pilot circle and a thin 270-degree major arc."""
        c=self.c;c.setStrokeColor(HexColor(color));c.setLineWidth(1)
        radius=(2.5 if tapped else major/2)*scale;c.circle(x,y,radius,stroke=1,fill=0)
        if tapped:
            r=major/2*scale;c.setLineWidth(.45);c.arc(x-r,y-r,x+r,y+r,startAng=20,extent=270)
        self.line(x-2,y,x+2,y,color,.35);self.line(x,y-2,x,y+2,color,.35)

    def leader(self,x,y,kx,ky,tx,ty,label,color=INK):
        self.line(x,y,kx,ky,color);self.line(kx,ky,tx,ky,color)
        self.text(tx,ty,label,10,color)

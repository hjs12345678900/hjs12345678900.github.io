"""V0.5 review geometry in mm; deterministic CAD, without file I/O or FEA.

Source-raster features are provisional. Threads, counterbores, exact dovetail
contact geometry and saddle jaw compliance are not resolved by these solids.
"""
import math
import cadquery as cq


def map_rail_raster(bottom, u, v):
    """Map one source-raster (u,v) pixel centre to global (X,Y) in mm.

    The four registered corners in bottom['raster_registration'] establish an
    affine X scale and linearly varying Y scale. +Y points upwards on the image.
    Returns two floats; tracing uncertainty is separate from numerical precision.
    """
    r = bottom['raster_registration']
    f = (u-r['left_u'])/(r['right_u']-r['left_u'])
    top = r['top_v_left']+f*(r['top_v_right']-r['top_v_left'])
    low = r['bottom_v_left']+f*(r['bottom_v_right']-r['bottom_v_left'])
    return (f-.5)*bottom['length_mm'], (.5-(v-top)/(low-top))*bottom['max_width_mm']


def make_rail(bottom, height=None):
    """Return a single perforated rail review solid, based at Z=0, in mm.

    height overrides the unmeasured bottom_plate_height. Major slots and visible
    circles are removed through the profile. This cannot certify female thread
    engagement or vendor mass; purchased mass is kept separately in the budget.
    Raises ValueError when the assumed profile cannot fit within its total height.
    """
    h = bottom['bottom_plate_height'] if height is None else height
    wide, narrow = bottom['max_width_mm']/2, bottom['clamping_width_mm']/2
    lip = bottom['lip_height_mm']
    bevel = (wide-narrow)*math.tan(math.radians(bottom['flank_angle_deg']))
    if h <= lip+bevel:
        raise ValueError('Assumed lip and bevel exceed rail height')
    pts = [(-narrow,0),(narrow,0),(narrow,h-lip-bevel),(wide,h-lip),
           (wide,h),(-wide,h),(-wide,h-lip),(-narrow,h-lip-bevel)]
    rail = cq.Workplane('YZ').polyline(pts).close().extrude(bottom['length_mm']/2,both=True)
    for s in bottom['slots']:
        x,y = map_rail_raster(bottom,s['source_u'],s['source_v'])
        cutter = cq.Workplane('XY').center(x,y).slot2D(s['length_mm'],s['width_mm']).extrude(h+2).translate((0,0,-1))
        rail = rail.cut(cutter)
    for hole in bottom['holes']:
        x,y = map_rail_raster(bottom,hole['source_u'],hole['source_v'])
        cutter = cq.Workplane('XY').center(x,y).circle(hole['diameter_mm']/2).extrude(h+2).translate((0,0,-1))
        rail = rail.cut(cutter)
    return rail


def make_saddle(s):
    """Return local XY saddle review solid with its base at Z=0, units mm.

    Four independent mounting slots and three central holes are cut through.
    The open stepped channel represents the two nominal clearance envelopes,
    not an exact 60/75-degree jaw profile. No mass/CoG is inferred from the solid.
    """
    w,l,h = s['overall_x_mm'],s['overall_y_mm'],s['height_mm']
    saddle = cq.Workplane('XY').box(w,l,h).translate((0,0,h/2)).edges('|Z').fillet(s['outline_corner_radius_mm'])
    # Preserve the drawn 14.7 mm base floor and 24.65 mm intermediate level.
    for width,z in [(s['vixen_channel_nominal_width_mm'],s['base_thickness_mm']),
                    (s['losmandy_channel_nominal_width_mm'],s['intermediate_height_mm'])]:
        cutter = cq.Workplane('XY').box(width,l+2,h-z+2).translate((0,0,z+(h-z+2)/2))
        saddle = saddle.cut(cutter)
    for slot in s['slots']:
        cut = cq.Workplane('XY').center(slot['x_mm'],slot['y_mm']).slot2D(slot['length_mm'],s['slot_width_mm'],slot['angle_deg']).extrude(h+2).translate((0,0,-1))
        saddle = saddle.cut(cut)
    for x in s['central_holes_x_mm']:
        saddle = saddle.cut(cq.Workplane('XY').center(x,0).circle(s['central_hole_diameter_mm']/2).extrude(h+2).translate((0,0,-1)))
    return saddle


def build_assembly(p):
    """Return five named CadQuery solids in global X/Y/Z, dimensions in mm.

    The rail top and plate underside share Z=bottom_plate_height, without a gap.
    A/B/C centre locations are taken solely from telescope_centres_x_mm.
    No bolts or drilled top-plate holes are supplied before Stage 2 selection.
    """
    top,rail,s = p['top_plate'],p['bottom_plate'],p['saddle']
    h,t = rail['bottom_plate_height'],top['thickness_mm']
    parts = {'rail_PROFILE_AND_HOLE_MAP_HOLD':make_rail(rail),
             'top_plate_BLANK':cq.Workplane('XY').box(top['length_mm'],top['width_mm'],t).translate((0,0,h+t/2))}
    local = make_saddle(s)
    for letter,x in zip('ABC',p['telescope_centres_x_mm']):
        parts[f'saddle_{letter}_REVIEW'] = local.translate((x,0,h+t))
    return parts

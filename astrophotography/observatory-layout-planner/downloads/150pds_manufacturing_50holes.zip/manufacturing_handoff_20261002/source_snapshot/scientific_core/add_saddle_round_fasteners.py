"""Add two original round-hole fasteners per saddle without changing bought parts.

Coordinates are plate-centred mm. These taps are tied to the selected aligned
pose; alternate saddle positions require their corresponding adapter variant.
The original centre round hole remains unused. Seat reconstruction is only a
conditional representation of the existing recess, not a machining instruction.
"""
from scientific_core.build_bolted_adapter import cylinder


def round_tap_rows(centres):
    """Return six M6 pilot records for three selected saddle centres, mm.

    centres is a length-three iterable of signed X centres. Each saddle uses
    its original X=±20, Y=0 holes, so the paired span is exactly 40 mm nominal.
    This nominal list must be transferred after actual saddle alignment.
    """
    rows=[]
    for label,x in zip(['L','M','R'],centres):
        for side,dx in [('left',-20),('right',20)]:
            rows.append(dict(id=f'{label}-round-{side}',x=x+dx,y=0,d=5,major=6,
                             kind='TAP',source='Original Ø6.5 round hole; transfer after alignment',
                             pattern=label+'-round',estimated_x=False))
    return rows


def reconstruct_round_seats(saddle,p):
    """Open the existing Ø11 seat envelope at X=±20; assumed depth in mm.

    The straight cylindrical entry is an approximation of the original visible
    stepped recess. Depth remains unmeasured; the three-hole source drawing
    establishes hole locations but does not establish this bearing elevation.
    """
    bearing=14.7-p['saddle_seat_depth_assumed_mm']
    for x in [-20,20]:
        saddle=saddle.cut(cylinder(5.5,bearing,31.5-bearing+1).translate((x,0,0)))
    return saddle


def round_bolt(p):
    """Return a conditional low-head M6x18 envelope without a washer.

    Under-head support is the original annular round-hole seat. A Ø10×4 head
    fits the model's Ø11 recess. With the assumed 6 mm recess, engagement is
    9.3 mm and tip clearance is 2.7 mm. Actual bearing width is unverified.
    Embedded thread is a Ø5 cylinder matching the pilot-only adapter model.
    """
    top=p['rail_height_est_mm']+12
    head=top+14.7-p['saddle_seat_depth_assumed_mm'];tip=head-18
    return cylinder(2.5,tip,top-tip).union(cylinder(3,top,head-top)).union(cylinder(5,head,4))

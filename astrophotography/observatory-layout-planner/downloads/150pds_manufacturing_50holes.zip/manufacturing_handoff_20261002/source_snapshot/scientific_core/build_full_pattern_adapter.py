"""Put all three detents' saddle holes on one adapter; all lengths are mm.

This corrects the selected-pose interpretation in V1.5.0. The purchased
saddles still use only two of their three original transverse round holes.
Their alternate detent locations are all cut into the new plate. The nearest
M6 major-diameter ligament is only 2 mm; strength is not inferred from fit.
"""
import itertools
import math
from scientific_core.build_aligned_adapter import aligned_rows,aligned_checks


def full_pattern_rows(p):
    """Return 50 unique holes: 8 lower clearances and 42 upper M6 pilots.

The upper set comprises 28 slot-pattern taps and 14 round-pattern taps:
six for each outer saddle and two for the centre saddle. Installed screws
remain six per saddle; alternate taps are unoccupied at a given pose.
"""
    rows=aligned_rows(p,include_round=False)
    seen={(r['x'],r['y']) for r in rows}
    for detent in (0,16,32):
        for r in aligned_rows(p,detent,detent):
            if r['connection']!='round' or (r['x'],r['y']) in seen:
                continue
            r=dict(r)
            label=r['pattern'][0]
            r['id']=r['id']+f'-{detent}'
            r['pattern']=f'{label}{detent}-round'
            r['source']='Original lateral round hole, all nominal detents; measure before machining'
            rows.append(r);seen.add((r['x'],r['y']))
    return rows


def full_pattern_checks(p):
    """Check union coverage across nine poses and report minimum hole web."""
    rows=full_pattern_rows(p);result=aligned_checks(p)
    points={(r['x'],r['y']) for r in rows}
    coverage=[]
    for left,right in itertools.product((0,16,32),repeat=2):
        required={(r['x'],r['y']) for r in aligned_rows(p,left,right)}
        missing=required-points
        assert not missing,(left,right,missing)
        coverage.append(dict(left=left,right=right,required_holes=len(required),missing=[]))
    pairs=[(math.hypot(a['x']-b['x'],a['y']-b['y'])-(a['major']+b['major'])/2,a['id'],b['id'])
           for a,b in itertools.combinations(rows,2)]
    gap,a,b=min(pairs)
    assert len(rows)==50 and len(points)==50
    result.update(hole_count=50,upper_taps=42,round_pattern_taps=14,
                  added_vs_selected_pose=8,one_common_plate=True,
                  minimum_finished_hole_web_mm=gap,minimum_web_pair=[a,b],
                  detent_hole_coverage=coverage)
    return result

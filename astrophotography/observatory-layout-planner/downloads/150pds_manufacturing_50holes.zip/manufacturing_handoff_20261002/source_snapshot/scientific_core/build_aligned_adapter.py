"""Align only the outer saddles to rail Y rows and add selected round taps.

All lengths use mm. The approximately 27.8 mm rail row remains an estimate,
not a new source dimension. Shared two-hole bearing strips replace overlapping
round washers; their stiffness and practical head tolerances remain unverified.
"""
import itertools
import math
import cadquery as cq
from scientific_core.build_bolted_adapter import (
    schedule,make_adapter,make_reference_saddle,hardware,check_layout)
from scientific_core.add_saddle_round_fasteners import (
    round_tap_rows,reconstruct_round_seats,round_bolt)


def aligned_rows(p,left=0,right=0,include_round=True):
    """Return 36 pre-transfer or 42 selected-pose hole records, mm.

    left/right are outward detents in {0,16,32}. Centre saddle retains the
    original Y values. Only six round taps for the selected pose are cut;
    this avoids drilling all fourteen alternatives separated by as little
    as 8 mm (2 mm material between finished M6 major diameters).
    """
    if left not in (0,16,32) or right not in (0,16,32):
        raise ValueError('Unsupported detent')
    q=dict(p,upper_y_mm=p['aligned_outer_y_mm'])
    rows=schedule(q)
    for r in rows:
        r['connection']='lower' if r['kind']=='CLEAR' else 'slot'
        if r.get('pattern')=='M':
            index=int(r['id'].split('-')[1])-1;r['y']=p['upper_y_mm'][index]
    if include_round:
        for r in round_tap_rows([-222-left,0,222+right]):
            r['connection']='round';rows.append(r)
    return rows


def bearing_strip(p):
    """Return one custom 21.12×11×1.6 mm capsule strip with two Ø6.4 holes.

    Local centres are at Y=±5.06 mm. Its underside elevation is the same
    assumed saddle seat used in the previous model. The 3.72 mm ligament
    between holes is geometry only, not a pressure or bending assessment.
    """
    pitch=p['aligned_outer_y_mm'][3]-p['aligned_outer_y_mm'][2]
    z=p['rail_height_est_mm']+12+14.7-p['saddle_seat_depth_assumed_mm']
    w=cq.Workplane('XY').slot2D(pitch+11,11,90).extrude(1.6)
    cut=cq.Workplane('XY').pushPoints([(0,-pitch/2),(0,pitch/2)]).circle(3.2).extrude(1.6)
    return w.cut(cut).translate((0,0,z))


def aligned_base(p,rail):
    """Return reusable solids; adapter depends on pose and is generated later."""
    return dict(rail=rail,saddle=reconstruct_round_seats(make_reference_saddle(p),p),
                strip=bearing_strip(p),round_bolt=round_bolt(p),**hardware(p))


def aligned_instances(p,base,left=0,right=0,plate=None):
    """Return 55 named solids at one pose, including 18 saddle screws."""
    h=p['rail_height_est_mm']
    if plate is None:plate=make_adapter(p,aligned_rows(p,left,right))
    parts=[('rail',base['rail'],'rail',0),('adapter',plate.translate((0,0,h)),'adapter',0)]
    for i,r in enumerate(q for q in aligned_rows(p) if q['kind']=='CLEAR'):
        for kind in ['lower_bolt','lower_washer','lower_nut']:
            parts.append((f'{kind}_{i+1}',base[kind].translate((r['x'],r['y'],0)),kind,0))
    for name,x in zip(['L','M','R'],[-222-left,0,222+right]):
        parts.append((f'saddle_{name}',base['saddle'].translate((x,0,h+12)),'saddle',x))
        ys=p['upper_y_mm'] if name=='M' else p['aligned_outer_y_mm']
        for i,y in enumerate(ys):
            parts.append((f'upper_bolt_{name}{i}',base['upper_bolt'].translate((x,y,0)),'upper_bolt',x))
            if name=='M':
                parts.append((f'upper_washer_{name}{i}',base['upper_washer'].translate((x,y,0)),'upper_washer',x))
        if name!='M':
            for sign in [-1,1]:
                y=sign*(ys[2]+ys[3])/2
                parts.append((f'strip_{name}_{sign}',base['strip'].translate((x,y,0)),'strip',x))
        for i,dx in enumerate([-20,20]):
            parts.append((f'round_bolt_{name}{i}',base['round_bolt'].translate((x+dx,0,0)),'round_bolt',x))
    return parts


def aligned_checks(p):
    """Return source-row, hole-web, slot and bearing-strip envelope checks."""
    rows=aligned_rows(p);pitch=p['aligned_outer_y_mm'][3]-p['aligned_outer_y_mm'][2]
    result=check_layout(p)
    margins=[]
    for y in p['aligned_outer_y_mm']:
        slotcentre=math.copysign(22.575,y)
        axial=max(abs(y-slotcentre)-(18.25-8.3)/2,0)
        margins.append((8.3-6)/2-axial)
    pairs=[(math.hypot(a['x']-b['x'],a['y']-b['y'])-(a['major']+b['major'])/2,a['id'],b['id'])
           for a,b in itertools.combinations(rows,2)]
    gap,a,b=min(pairs)
    result.update(hole_count=42,upper_taps=34,lower_clearances=8,
                  pre_transfer_hole_count=36,saddle_screws_installed=18,
                  minimum_finished_hole_web_mm=gap,minimum_web_pair=[a,b],
                  outer_Y_mm=p['aligned_outer_y_mm'],centre_Y_mm=p['upper_y_mm'],
                  minimum_washer_pair_gap_mm=None,round_washers_replaced_on_outer_saddles=True,
                  outer_slot_pair_pitch_mm=pitch,outer_head_gap_mm=pitch-10,
                  old_round_washer_overlap_mm=11-pitch,
                  outer_shank_slot_margins_mm=margins,
                  shared_strip_mm=[pitch+11,11,1.6],shared_strip_hole_pitch_mm=pitch,
                  shared_strip_hole_diameter_mm=6.4,shared_strip_hole_web_mm=pitch-6.4,
                  added_round_pair_span_mm=40,round_thread_engagement_mm=9.3,
                  round_tip_above_adapter_bottom_mm=2.7,
                  round_hole_radial_shank_clearance_ceiling_mm=.25,
                  Y_27_8_source='estimated rail row; not manufacturer dimension',
                  shared_strip_strength_verified=False,head_tolerance_fit_verified=False)
    return result

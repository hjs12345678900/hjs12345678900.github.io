"""Build the C-pocket bolted adapter concept in mm, without external I/O.

Inputs are the newly reviewed source trace and an explicit configuration.
Purchased solids are reference reconstructions, not instructions to modify
them. Thread cylinders are geometric envelopes, never true thread profiles.
Rail thickness and pocket shape/depth remain approximate source information.
"""
import itertools
import math
import cadquery as cq
from scientific_core.build_simple_plate_geometry import make_saddle


def source_x(u):
    """Return signed X in mm using local source dimension-chain anchors.

    u is an independently traced pixel coordinate in the 2048-pixel view.
    Piecewise interpolation prevents a global raster scale from overriding
    the source's 35 + 35 + 43.65 mm chain. Interpolated positions are estimates.
    """
    anchors = [(161,-222.5),(232,-201.15),(428,-148.65),(558,-113.65),
               (722,-70),(854,-35),(984,0)]
    if u > 984:
        return -source_x(1968-u)
    for (a,x),(b,y) in zip(anchors,anchors[1:]):
        if a <= u <= b:
            return x+(u-a)/(b-a)*(y-x)
    raise ValueError('Trace outside registered rail')


def source_y(v):
    """Map traced source rows to symmetric nominal Y mm; outer row estimated."""
    delta=494-v
    distance=min((0,37,65.5,102),key=lambda q:abs(abs(delta)-q))
    return math.copysign({0:0,37:10,65.5:17.68,102:27.8}[distance],delta)


def rail_holes(trace):
    """Return the reviewed five-class holes with explicit raster provenance."""
    diam={'M4':3.3,'M6':5.1,'M8':6.9,'3/8':8.1,'THRU':6.5}
    rows=[]
    for r in trace['records']:
        u,v=r['source_view_xy']
        for sign in ([1,-1] if u != 984 else [1]):
            rows.append(dict(x=sign*source_x(u),y=source_y(v),d=diam[r['kind']],
                             kind=r['kind'],zone=r['zone'],evidence=r['evidence']))
    return rows


def schedule(p):
    """Return 8 lower clearances and 28 upper taps in plate-centred mm.

    Only C-region through holes 1,2,5,6 on each side are selected. The outer
    X station follows a labelled chain; the inner X station is interpolated.
    Upper M6 bores are represented by 5 mm pilots in the adapter STEP.
    """
    rows=[]
    for x in [-113.65,source_x(689),-source_x(689),113.65]:
        for y in [-10,10]:
            rows.append(dict(id=f'R{len(rows)+1}',x=x,y=y,d=6.5,major=6.5,
                             kind='CLEAR',source='C pocket; original Ø6.5 through',
                             estimated_x=abs(x)!=113.65))
    for label,centre in [('L32',-254),('L16',-238),('L0',-222),('M',0),
                         ('R0',222),('R16',238),('R32',254)]:
        for i,y in enumerate(p['upper_y_mm'],1):
            rows.append(dict(id=f'{label}-{i}',x=centre,y=y,d=5,major=6,
                             kind='TAP',source='M6x1 via original inner saddle slots',
                             pattern=label,estimated_x=False))
    return rows


def make_adapter(p,rows=None):
    """Return a 600×120×12 mm solid from optional hole records; Z=0 below.

    rows, when supplied, uses the same x/y/d mm fields as schedule(p).
    """
    rows=schedule(p) if rows is None else rows
    plate=cq.Workplane('XY').box(600,120,12,centered=(True,True,False))
    for d in (5,6.5):
        points=[(r['x'],r['y']) for r in rows if r['d']==d]
        plate=plate.cut(cq.Workplane('XY').pushPoints(points).circle(d/2).extrude(14).translate((0,0,-1)))
    return plate


def pocket_polygons():
    """Return approximate existing C/D underside recess outlines in mm.

    The silhouette is simplified from the source. No contour, radius or
    bearing-width accuracy is implied. It is not a new machining operation.
    """
    c=[(-128,-22),(-117,-24),(-77,-24),(-73,-20),(-73,-14),(-72,-10),
       (-75,-5),(-75,5),(-72,10),(-73,14),(-73,20),(-77,24),(-117,24),(-128,22)]
    d=[(-69,-12),(-65,-13),(-65,-18),(-57,-24),(-43,-24),(-24,-24),
       (-14,-22),(-12,-16),(-6,-10),(-10,-5),(-10,5),(-6,10),(-12,16),
       (-14,22),(-24,24),(-43,24),(-57,24),(-65,18),(-65,13),(-69,12)]
    return [c,d,[(-x,y) for x,y in c],[(-x,y) for x,y in d]]


def make_reference_rail(p,trace):
    """Return the purchased-rail approximation at Z=0; no new rail holes."""
    h=p['rail_height_est_mm'];lip=2;bevel=3*math.tan(math.radians(60))
    pts=[(-37,0),(37,0),(37,h-lip-bevel),(40,h-lip),(40,h),(-40,h),(-40,h-lip),(-37,h-lip-bevel)]
    rail=cq.Workplane('YZ').polyline(pts).close().extrude(222.5,both=True)
    rows=rail_holes(trace)
    for d in sorted({r['d'] for r in rows}):
        xy=[(r['x'],r['y']) for r in rows if r['d']==d]
        rail=rail.cut(cq.Workplane('XY').pushPoints(xy).circle(d/2).extrude(h+2).translate((0,0,-1)))
    slots=[(179,300,430,10),(179,280,494,10),(179,290,558,10),
           (400,493,430,10),(400,493,558,10),(576,688,430,13),
           (576,688,558,13),(735,897,457,12),(735,897,531,12),(811,893,494,11)]
    for a,b,v,half in slots:
        x1,x2=source_x(a),source_x(b);y=(494-v)/3.7
        for sign in [-1,1]:
            cut=cq.Workplane('XY').center(sign*(x1+x2)/2,y).slot2D(x2-x1,2*half/3.7).extrude(h+2).translate((0,0,-1))
            rail=rail.cut(cut)
    for poly in pocket_polygons():
        rail=rail.cut(cq.Workplane('XY').polyline(poly).close().extrude(p['pocket_depth_approx_mm']))
    return rail


def cylinder(radius,z,height):
    """Return a centred Z cylinder; all arguments use mm."""
    return cq.Workplane('XY').circle(radius).extrude(height).translate((0,0,z))


def make_reference_saddle(p):
    """Reconstruct existing inner-slot seats using explicitly assumed depth.

    Seat width 15.8 mm is a prior image estimate; 6 mm depth is an assembly
    scenario only. This does not request or authorize machining the saddle.
    """
    saddle=make_saddle(p['saddle'])
    depth=p['saddle_seat_depth_assumed_mm']
    for y in [-22.575,22.575]:
        pocket=cq.Workplane('XY').center(0,y).slot2D(25.75,15.8,90).extrude(depth).translate((0,0,14.7-depth))
        saddle=saddle.cut(pocket)
    return saddle


def washer(outer,z):
    """Return the assumed Ø6.4 ID, 1.6 mm washer envelope, OD=outer mm."""
    return cq.Workplane('XY').circle(outer/2).circle(3.2).extrude(1.6).translate((0,0,z))


def hardware(p):
    """Return local bolt/nut/washer envelopes in assembled global Z, mm.

    M6x30 lower and low-head M6x20 upper are candidate lengths only. Upper embedded
    shafts use 5 mm diameter to mate with pilot-only STEP without false clash.
    No preload, contact stress, tensile capacity or real thread fit is modeled.
    """
    rail=p['rail_height_est_mm'];seat=p['pocket_depth_approx_mm'];top=rail+12
    bolt=cylinder(5,seat-6,6).union(cylinder(3,seat,30))
    nut=cq.Workplane('XY').polygon(6,10/math.cos(math.pi/6)).circle(3).extrude(5.2).translate((0,0,top+1.6))
    bearing=top+14.7-p['saddle_seat_depth_assumed_mm']
    head=bearing+1.6;tip=head-20
    upper=cylinder(2.5,tip,top-tip).union(cylinder(3,top,head-top)).union(cylinder(5,head,4))
    return dict(lower_bolt=bolt,lower_washer=washer(12,top),lower_nut=nut,
                upper_bolt=upper,upper_washer=washer(11,bearing))


def check_layout(p):
    """Return deterministic planar clearance screens in mm; not load checks."""
    rows=schedule(p);lower=[r for r in rows if r['kind']=='CLEAR']
    web=min(math.hypot(a['x']-b['x'],a['y']-b['y'])-(a['major']+b['major'])/2
            for a,b in itertools.combinations(rows,2))
    mirror=max(min(math.hypot(r['x']*sx-q['x'],r['y']*sy-q['y'])
                   for q in rows if q['kind']==r['kind']) for r in rows for sx,sy in [(1,-1),(-1,1)])
    poses=[]
    for left,right in itertools.product([0,16,32],repeat=2):
        centres=[-222-left,0,222+right]
        gap=min(abs(r['x']-s)-51-9 for r in lower for s in centres)
        poses.append(dict(left=left,right=right,min_assumed_OD18_tool_to_saddle_mm=gap,
                          saddle_end_overhang_mm=max(0,left-27,right-27)))
    return dict(hole_count=len(rows),lower_clearances=8,upper_taps=28,
                minimum_finished_hole_web_mm=web,reflection_error_mm=mirror,poses=poses,
                lower_head_above_rail_bottom_mm=p['pocket_depth_approx_mm']-6,
                rail_remaining_web_approx_mm=p['rail_height_est_mm']-p['pocket_depth_approx_mm'],
                lower_pair_tool_gap_mm=20-18,upper_thread_engagement_envelope_mm=9.7,
                upper_tip_above_adapter_bottom_mm=2.3,
                minimum_washer_pair_gap_mm=11.5-11,
                manufacturing_release=False,strength_verified=False,
                tool_OD18_assumed=True,recess_shape_and_bearing_seat_verified=False)

# 当前 50 孔转接板：STEP 与加工交底图（V1.7.0）

本包沿用当前 600×120×12 mm、50 孔共用板，未改变几何或增厚。左右各 0/16/32 mm 档位的孔全部保留；装配 STEP 展示左右各外移 16 mm。

## 给加工方的文件

- `output/pdf/adapter_50holes_machining_A3.pdf`：单页 A3 转接板图，以尺寸线标出全部孔位、板厚、孔型、建议公差及加工要求。
- `cad/adapter_600x120x12_50holes_TAP_PILOTS.step`：转接板实体；**42 个螺纹孔以 Ø5.0 底孔建模，必须按图攻 M6×1-6H 通牙，不能当成 Ø5 成品通孔。**
- `cad/adapter_50holes_drill_and_tap.dxf`：毫米制、板中心原点；8 个光孔和 42 个攻牙底孔分层。`NOTES_NO_CUT` 是说明层，不切割。
- `cad/assembly_L16_R16_55parts.step`：55 实体参考装配，含采购件和简化紧固件，不能把全部实体作为待加工零件。
- `output/pdf/shared_strip_machining_A4.pdf` 与 `cad/shared_two_hole_strip.step`：外侧四件共用双孔垫片，21.12×11×1.6 mm，2×Ø6.4 通孔，孔距 10.12 mm。
- `hole_schedule_drill_and_tap.csv`：辅助数控录入的孔位数据，包含中心坐标、边缘坐标、是否螺纹孔；PDF 无坐标表。

## 孔型与制造要求

转接板共 **8×Ø6.5 通孔、不攻牙；42×M6×1-6H 右旋通螺纹孔**。42 孔包括 28 个长槽连接孔和 14 个侧边圆孔连接孔。每个实际装配档位使用 18 颗上部螺钉，其余孔供调档使用，不应省略。新板不加沉孔、沉头或凹槽。

Ø5.0 为切削丝锥的名义底孔，挤压丝锥不适用该底孔要求。按图检查通止规；采购件与底板现有孔不要求重新攻牙。图纸建议采用 6061-T6，外形 600±0.20、120±0.10、厚度 12±0.10 mm；孔中心相对板中心 X/Y 各 ±0.05 mm，两面平面度和相互平行度 0.10 mm，接触面 Ra3.2。这些是本次提出的加工要求，并非供应商已确认数据。按 PDF 的独立坐标公差解释尺寸链，不累积链式误差。

## 下料前需要核实的配合尺寸

图中星号尺寸仍源自估测：底板内侧连接孔 X=±78.783232 mm，以及外侧长槽连接孔 Y=±27.800 mm。应以实际底板和鸠尾槽复核、必要时修订图纸后再加工；本包可用于加工沟通和报价，不是免复核的投产放行。

双孔垫片的 10.12 mm 孔距跟随上述外侧孔排；钢材牌号/硬度待选定，局部承压和弯曲未验证。外侧相邻名义 Ø10 螺钉头间隙仅 0.12 mm，要验证实际头径、垫片与工具能否装入。替代档位 M6 大径之间最小余料 2 mm。STEP 中底板厚度、凹槽和采购件局部尺寸仍包含估测值，只供装配参考。

## 验证与复现

转接板与垫片 STEP 均回读为有效单实体且体积一致；转接板外形 600×120×12 mm，50 个圆柱孔面。装配含 55 个有效实体，与原装配文件字节一致。DXF 审计通过，8 个 Ø6.5 光孔与 42 个 Ø5.0 攻牙底孔分层数量一致。两张 PDF 已渲染检查，无遮挡或截断。具体记录见 `export_checks.json`。上述验证不代替实测配合或整机强度认证。

源代码快照见 `source_snapshot/`，输入参数见 `parameters.json`。在原项目工作区运行：

```sh
MPLCONFIGDIR=/tmp/mount-mpl OPENBLAS_NUM_THREADS=1 .venv-mount-audit/bin/python three150pds_mount_audit/src/pipelines/export_manufacturing_handoff.py
MPLCONFIGDIR=/tmp/mount-mpl OPENBLAS_NUM_THREADS=1 .venv-mount-audit/bin/python three150pds_mount_audit/src/visualization/draw_manufacturing_handoff.py
```

源 STEP 来自 `runs/all_detent_holes_20261002/cad/`，此包中的 source_snapshot 是追溯存档，不是独立安装包。图纸中螺纹加工说明优先于 STEP/DXF 的简化底孔几何。

切削丝锥规格参考：[OSG M6×1 6H 通孔丝锥](https://osgtool.com/2888301/)、[Gühring 1858 系列](https://guhring.com/ProductsServices/SeriesDetails?Series=1858)。最终刀具及工艺由加工方按材料和成品螺纹要求选定。

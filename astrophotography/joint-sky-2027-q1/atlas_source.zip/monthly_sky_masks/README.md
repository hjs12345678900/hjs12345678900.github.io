# 2027 Q1 甘肃–ASV：月度 DSS2 Red 遮罩选图

网站版入口：[JSH / ASTRO 双站星图](https://hjs12345678900.github.io/astrophotography/joint-sky-2027-q1/)。网站版1.2.0保留原版计算模型，采用China-VO的真实DSS2 Red高清镜像与CDS备用地址；不需要本地服务。镜像Allsky与IRSA缓存SHA-256完全相同。网络不可用时保留内置广域预览。网页提供来源、WCS FITS和源代码下载；主页天文摄影档案中加入了独立入口。网站适配及浏览器核验脚本位于`src/pipelines/prepare_website_release.py`和`check_website_browser.js`，验证记录为`data/website_*validation.json`。

高清浏览建议双击 **[open_dss2_red.command](open_dss2_red.command)**，会打开仅在本机运行的缓存浏览入口。也可直接打开 **[DSS2 Red 星图](sky_atlas_red.html)** 使用本地预览（`sky_atlas.html`也已默认改为Red）。[原彩色版](sky_atlas_color.html)及其静态图保留在`figures/color/`。这是新增的独立图集，原选题报告、表格、脚本和交付清单未改写。

## 如何自己选

1. 选择1、2或3月。默认保留“目标≥30°、月亮在地平线下、两站各自至少10小时”的区域。
2. 亮区显示真实DSS2 Red灰度图；暗区未达到门槛。默认两站可以分别累计，并不要求同步曝光。
3. 可切换40°、取消月下筛选、调整每月最低小时，或改看“真正同时”窗口。最低小时是每个站分别达到的要求；同时模式则要求真正交集达到该数值。
4. 拖动、滚轮放大，点击任意天区。下方显示两站各自小时、两站工时之和、真正同时小时，以及各站最长连续窗口和“哪天晚上”。
5. 三个相机矩形按天球投影绘制；可切换长边东西/南北。点击“放大到所选区域”比较画幅，再“加入我的候选”“导出候选CSV”。选点暂存在当前页面，关闭前请导出。

本地全景预览约7′有效采样，不适合判断小星系结构。联网时自动使用STScI的DSS高分辨率分层巡天，放大后稍等图片细节载入。大幅缩放时会先显示粗预览，再显示真实细节；没有生成式放大。若浏览器不支持WebGL2，本地预览仍可拖动、缩放、切换遮罩和选点。

## 静态大图

- [三个月总览](figures/monthly_overlap_overview.png)
- [1月](figures/2027_01_dss_mask.png) · [2月](figures/2027_02_dss_mask.png) · [3月](figures/2027_03_dss_mask.png)

默认30°/月下/两站各≥10h。青线内为可选区，金虚线内为40°优选区。横轴赤经24h→0h，北上、东左。参考摄影底图的拼缝、光晕和色彩不用于暗结构定量确认。

## 科学方法与精度

- 站点、2027年1月1日至3月31日当地夜晚、5分钟中点UTC网格、太阳−18°、站心月球高度及未来IERS预测值，均复用父项目已经保存的真实Astropy计算。
- 晚间归属当地中午至次日中午；3月31日晚包含4月1日凌晨。甘肃UTC+8，ASV使用Australia/Melbourne，本季度AEDT/UTC+11。
- 本次新增计算的是整个RA 0–360°、Dec −30–+30°规划带，不受旧候选名单限制。共同达到30°或40°的天区均位于此带内，带外被遮暗。
- 使用Astropy将ICRS方向转换为每月16日的CIRS方向，逐个原始5分钟时格计算地球自转下的高度。月内慢变CIRS方向固定于月中；没有只用月中一个晚上代替整月。
- 高度关系：sin(h)=sin(φ)sin(δ)+cos(φ)cos(δ)cos(H)。每个站的可拍条件对应时角区间，通过排序后的实际合格时格精确计数；真正同时使用两站同一UTC时格的联合太阳/月球限制和两个时角区间的交集。不存在用min(单站小时)冒充同时小时的做法。
- 地图空间网格0.25°。所有47个旧候选×36种逐月条件共1692项与完整AltAz对照，最大时长差约5分钟。月中CIRS方向近似在已检样本中的高度差小于0.002°；数值保留很多小数不意味着逐秒准确。
- 点击点的ICRS→CIRS修正采用1°网格双线性插值，然后按真实5分钟时格计数；最长窗口也从实际时序连续段得到，不从月合计猜测。旧候选用于核验，完全不参与限制用户能选择的方向。
- 模型为几何地平线，未知海拔按0m，不含地形、天气、透明度、消光、天空背景、设备开销或完整月光散射模型。所有小时是上限。相机大视场四角不一定与中心同时满足高度门槛。

不同目标争用同一夜晚，各点小时不能相加当作整季可实现工时。相机框仅表达角覆盖，不代表实际分辨率、面亮度极限或某个暗弱结构必然可拍。

## 真实DSS、坐标和版权

当前底图来自[NASA/IPAC IRSA托管的DSS2 Red HiPS](https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/red/)。实际重新下载了该红波段的`properties`和`Norder3/Allsky.jpg`，记录在`data/raw/red_asset_sources.json`，不是从DSSColor提取红通道。源JPEG虽然使用RGB存储，但三个通道逐像素完全相同；本图按灰度显示真实摄影红波段。原DSS由STScI/NASA及原摄影巡天机构提供，CDS完成HEALPix编码，完整署名见`data/raw/dss2_red_properties.txt`。DSS2 Red包含北天POSS2/UKSTU Red及南天AAO Red等红摄影底片，不能当作Hα窄带。

HiPS Allsky由768个order-3 tile按27列排列，每tile降采样为64×64，对应有效HEALPix nside512。`astropy-healpix`把真实像素重投影为北上东左的ICRS CAR图。内部tile方向用四幅独立缓存DSS FITS对照核验，结果在`data/red_reprojection_validation.json`；未以漂亮照片猜比例。预览显示使用统一gamma拉伸，不修补、涂画或生成星云。

参考：[IVOA HiPS Allsky格式](https://www.ivoa.net/Documents/HiPS/20260501/WD-HiPS-2.0-20260501.html)；[Astropy CIRS](https://docs.astropy.org/en/stable/api/astropy.coordinates.CIRS.html)；[Astropy Earth rotation angle](https://docs.astropy.org/en/stable/api/astropy.time.Time.html#astropy.time.Time.earth_rotation_angle)；[Aladin Lite文档](https://cds-astro.github.io/aladin-lite/)。

交互引擎Aladin Lite固定为3.9.2-beta，原模块和包说明保留在`assets/`；授权为LGPL-3.0-or-later，项目见<https://github.com/cds-astro/aladin-lite>。组装脚本仅将模块末尾export包装成浏览器全局变量，原源码保持可读。关闭组件启动日志，在线请求用于读取DSS巡天。

## 数据、代码与复算

- `data/monthly_sky_hours_wcs.fits`：36个带WCS的小时图层，站点/月份/高度/月亮条件保存在头信息。
- `data/dss2_red_car_preview_wcs.fits`：真实DSS2 Red单波段预览及ICRS CAR WCS。原彩色`data/dss_car_preview_wcs.fits`保留。
- `data/monthly_sky_counts.npz`：5分钟时格计数，axes为月/高度/月光/站点/赤纬/赤经。
- `tables/atlas_vs_full_altaz.csv`：1692项独立旧结果对照；`tables/monthly_sky_areas.csv`：不同条件的天区面积。
- `data/calculation_metadata.json`、`data/red_reprojection_validation.json`：计算输入哈希与映射核验。
- `output/playwright/`：实际浏览器交互检查截图和测试导出样本，后者不是用户自己挑的候选。

在本目录执行：

```sh
python3 src/pipelines/calculate_monthly_sky.py
python3 src/data_io/reproject_dss2_red.py
python3 src/visualization/render_monthly_dss_masks.py --survey red
python3 src/visualization/build_sky_atlas.py --survey red
```

Python基础依赖见父项目`requirements.txt`，新增`astropy-healpix==2.0.1`安装于本目录`vendor/`，没有更改全局Python。不同操作系统可以仅在此目录重装该依赖：

```sh
python3 -m pip install --no-deps --target vendor astropy-healpix==2.0.1
```

已有缓存可离线复算全部静态结果。若重新下载原始资源，运行`src/data_io/fetch_atlas_assets.py`；其中不存在的可选UMD路径保留失败记录，实际使用已经下载的ES模块。建议保留本次快照，另建副本重跑。

## DSS2 Red更新（v1.1.0）

只改变底图、来源标注与静态图；36层天时、相机几何、交互筛选和时间口径保持不变。源文件、Red映射核验在`data/red_variant_metadata.json`与`data/red_reprojection_validation.json`。`sky_atlas_color.html`是保留的彩色交互版；`figures/color/`为原四幅彩色静态图。下载Red资源可用`python3 src/data_io/fetch_atlas_assets.py --red-only`。

### Red高清浏览入口

IRSA镜像的JPEG缺少浏览器跨域读取头，CDS镜像在本机连接测试中超时。因此新增`src/pipelines/serve_red_atlas.py`，仅监听127.0.0.1；它以普通HTTPS获取同一套公开DSS2 Red文件，缓存到本目录`data/raw/red_tiles/`，不关闭浏览器安全检查，不接受任意上游网址。每个缓存文件的源URL、时间和SHA256写入`provenance.jsonl`。运行`python3 src/pipelines/serve_red_atlas.py --open`，或双击`open_dss2_red.command`。直接打开HTML时，在线源不可读会保持可拖动、缩放的本地Red预览，避免空白。

"""Render real DSS previews darkened outside computed monthly common sky."""
from pathlib import Path
import os
import argparse
ROOT=Path(__file__).resolve().parents[2]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'assets/mplcache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.colors import to_rgba
import numpy as np
from PIL import Image
from scipy.ndimage import zoom
import pandas as pd


def render_panel(ax,rgb,counts,ra,dec,month,height=30,moon=1,minimum=10,simultaneous=False,survey_label="DSS2 Red"):
    """Draw a north-up/east-left WCS-consistent CAR panel, preserving real pixels.

    rgb is top-origin ICRS CAR; counts are increasing-Dec/RA cell counts.
    A display gamma of 1/1.8 increases preview legibility, never adds structure.
    Visibility alpha is interpolated from the 0.25 degree hour grid.
    """
    h=(counts[2] if simultaneous else np.minimum(counts[0],counts[1]))/12
    ok=h>=minimum
    mask=np.asarray(Image.fromarray(ok[::-1,::-1].astype(np.uint8)*255).resize((rgb.shape[1],rgb.shape[0]),Image.Resampling.NEAREST))/255
    disp=np.power(rgb.astype(float)/255,1/1.8)*(.11+.89*mask[...,None])
    ax.imshow(disp,extent=[360,0,-30,30],origin='upper',aspect='auto')
    ax.contour(ra,dec,h,levels=[minimum],colors=['#20e0df'],linewidths=1.15)
    ax.set_xlim(360,0);ax.set_ylim(-30,30)
    ticks=np.arange(0,361,30)
    ax.set_xticks(ticks,labels=[f'{v//15}h' for v in ticks])
    ax.set_yticks([-30,-20,-10,0,10,20,30],labels=[f'{v:+d}°' for v in [-30,-20,-10,0,10,20,30]])
    ax.grid(color='white',alpha=.13,lw=.5)
    ax.tick_params(colors='#dce6ee',labelsize=10)
    for spine in ax.spines.values():spine.set_color('#44545f')
    ax.set_title(f'2027年{month}月   两站各自 ≥{minimum}h · 高度≥{height}° · '+('月亮落下' if moon else '不限月亮'),loc='left',fontproperties=FONT,color='white',fontsize=16,pad=13)
    ax.text(.995,1.03,survey_label,transform=ax.transAxes,ha='right',fontproperties=FONT,color='#bdcbd7',fontsize=12)
    ax.set_ylabel('赤纬 / Dec',fontproperties=FONT,color='#dce6ee')
    return ok

FONT=FontProperties(fname='/System/Library/Fonts/PingFang.ttc') if Path('/System/Library/Fonts/PingFang.ttc').exists() else FontProperties(family='Arial Unicode MS')


def main():
    """Write three monthly maps, a three-month overview and sky-area table."""
    parser=argparse.ArgumentParser();parser.add_argument('--survey',choices=['red','color'],default='red');args=parser.parse_args()
    is_red=args.survey=='red';out=ROOT/('figures' if is_red else 'figures/color');out.mkdir(exist_ok=True)
    label='DSS2 Red' if is_red else 'DSS Color'
    z=np.load(ROOT/'data/monthly_sky_counts.npz');v=z['counts'];ra=z['ra_deg'];dec=z['dec_deg']
    rgb=np.asarray(Image.open(ROOT/('assets/dss2_red_car_preview.jpg' if is_red else 'assets/dss_car_preview.jpg')).convert('RGB'))
    fig,axes=plt.subplots(3,1,figsize=(22,12),facecolor='#0b111a')
    area=[]
    for m,ax in enumerate(axes):
        ok=render_panel(ax,rgb,v[m,0,1],ra,dec,m+1,survey_label=label)
        preferred=np.minimum(v[m,1,1,0],v[m,1,1,1])/12
        ax.contour(ra,dec,preferred,levels=[10],colors=['#ffc065'],linewidths=1.05,linestyles='--')
        for altitude,hidx in [(30,0),(40,1)]:
            for moon in [0,1]:
                for simultaneous in [False,True]:
                    h=(v[m,hidx,moon,2] if simultaneous else np.minimum(v[m,hidx,moon,0],v[m,hidx,moon,1]))/12
                    row_area=np.deg2rad(.25)*(np.sin(np.deg2rad(dec+.125))-np.sin(np.deg2rad(dec-.125)))*(180/np.pi)**2
                    for threshold in [1,10,20,40]:
                        area.append(dict(month=f'2027-{m+1:02}',altitude_deg=altitude,moon_down=bool(moon),
                                         simultaneous=simultaneous,minimum_hours=threshold,
                                         area_square_deg=float(np.sum((h>=threshold)*row_area[:,None]))))
        single,sa=plt.subplots(figsize=(24,6),facecolor='#0b111a')
        render_panel(sa,rgb,v[m,0,1],ra,dec,m+1,survey_label=label)
        sa.contour(ra,dec,preferred,levels=[10],colors=['#ffc065'],linewidths=1.2,linestyles='--')
        sa.set_xlabel('赤经 / RA（东在左）',fontproperties=FONT,color='#dce6ee')
        single.text(.06,.025,f'真实 {label} / STScI–NASA–CDS · 青线：两站各≥10h@30°；金虚线：两站各≥10h@40° · 均为几何上限，未扣天气/地形。',fontproperties=FONT,color='#bdcbd7',fontsize=12)
        single.subplots_adjust(left=.06,right=.985,bottom=.17,top=.87)
        single.savefig(out/f'2027_{m+1:02}_dss_mask.png',dpi=180,facecolor=single.get_facecolor());plt.close(single)
    axes[-1].set_xlabel('赤经 / RA（东在左；全部24小时）',fontproperties=FONT,color='#dce6ee',fontsize=13)
    fig.text(.055,.975,f'甘肃 × ASV：每月共同可选天区 · {label}',fontproperties=FONT,color='white',fontsize=22)
    fig.text(.055,.942,'青线内保留DSS；两站可分别拍摄，不要求同一时刻。金虚线内达到40°优选条件。交互图可更改条件、放大并导出选点。',fontproperties=FONT,color='#bfccd8',fontsize=13)
    fig.text(.055,.02,f'底图：{label} 摄影巡天预览，约7′有效采样；拼缝和光晕不代表暗结构。5分钟时间网格，0.25°空间网格；天气、地形未计入。',fontproperties=FONT,color='#bfccd8',fontsize=12)
    fig.subplots_adjust(left=.055,right=.985,top=.90,bottom=.08,hspace=.43)
    fig.savefig(out/'monthly_overlap_overview.png',dpi=180,facecolor=fig.get_facecolor());plt.close(fig)
    pd.DataFrame(area).to_csv(ROOT/'tables/monthly_sky_areas.csv',index=False,encoding='utf-8-sig')
    print('Wrote three monthly DSS masks and overview')

if __name__=='__main__':main()

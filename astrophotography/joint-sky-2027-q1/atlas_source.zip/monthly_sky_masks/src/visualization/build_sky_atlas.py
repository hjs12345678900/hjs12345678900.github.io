"""Assemble a local, self-contained DSS mask atlas without external build tools.

The original LGPL Aladin module is retained in assets. The embedding wrapper
replaces only its final ES module export with window.A; no scientific or vendor
logic is changed. All original survey attribution remains available locally.
"""
from pathlib import Path
import base64
import argparse
import json
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[2]


def main():
    """Embed real DSS preview, precomputed model, scripts and responsive UI."""
    parser=argparse.ArgumentParser();parser.add_argument('--survey',choices=['red','color'],default='red');args=parser.parse_args()
    is_red=args.survey=='red'
    photo=np.asarray(Image.open(ROOT/('assets/dss2_red_car_preview.jpg' if is_red else 'assets/dss_car_preview.jpg')))
    display=(np.power(photo.astype(float)/255,1/1.8)*255).clip(0,255).astype(np.uint8)
    path=ROOT/('assets/dss2_red_car_display.jpg' if is_red else 'assets/dss_car_display.jpg');Image.fromarray(display).save(path,quality=92)
    image='data:image/jpeg;base64,'+base64.b64encode(path.read_bytes()).decode()
    raw=(ROOT/'data/point_model.json').read_text()
    vendor=(ROOT/'assets/aladin.js').read_text()
    assert vendor.count('export{f as default};')==1
    browser='(function(){\n'+vendor.replace('export{f as default};','window.A=f;')+'\n})();'
    (ROOT/'assets/aladin.browser.js').write_text(browser)
    model=(ROOT/'assets/sky_model.js').read_text();view=(ROOT/'assets/atlas_view.js').read_text()
    if is_red:
        view=view.replace("'https://stpubdata.s3.us-east-1.amazonaws.com/mast/skybackgrounds/DSSColor'","(window.RED_HIPS_SOURCE||'https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/red')").replace('DSS color / STScI–NASA–CDS','DSS2 Red / STScI–CDS / NASA-IPAC').replace('在线 DSS（','在线 DSS2 Red（').replace('本地 DSS 全天','本地 DSS2 Red 全天')
        view=view.replace('try{await A.init;const survey=',"try{await A.init;const base=(window.RED_HIPS_SOURCE||'https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/red');const probe=await fetch(base+'/Norder0/Dir0/Npix4.jpg',{signal:AbortSignal.timeout(8000)});if(!probe.ok)throw new Error('DSS2 Red image source unavailable');const survey=")
        view=view.replace('高清引擎未启用，当前本地DSS预览仍可拖动、缩放和选点。','当前为本地DSS2 Red预览；高清浏览请双击 open_dss2_red.command。')
        (ROOT/'assets/atlas_view_red.js').write_text(view)
    template='''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="data:,"/><title>2027 Q1 双站共同天区 · DSS 遮罩选图</title><style>
*{box-sizing:border-box}body{margin:0;background:#0a1018;color:#e5edf5;font:16px/1.5 system-ui,-apple-system,sans-serif}main{max-width:1600px;margin:auto;padding:22px}h1{font-size:26px;margin:0 0 8px}p{margin:6px 0 14px;color:#b7c8d9}.controls{display:flex;gap:12px;align-items:end;flex-wrap:wrap;margin:18px 0}.controls label{display:flex;flex-direction:column;gap:5px;font-size:14px}.inline{flex-direction:row!important;align-items:center;min-height:39px}select,input,button{font:inherit;color:inherit}select,button,input[type=number]{background:#172534;border:1px solid #45596b;padding:8px 10px;border-radius:5px}button{cursor:pointer}button:disabled{opacity:.45;cursor:default}input[type=range]{width:170px}a{color:#7edbe5}#sky{position:relative;width:100%;height:620px;max-height:70vh;min-height:360px;background:#03060b;overflow:hidden}#aladin,#offline,#mask,#frames{position:absolute;inset:0;width:100%;height:100%}#offline{z-index:1}#mask{z-index:5;pointer-events:none}#frames{z-index:6;pointer-events:none}#aladin{z-index:auto}#aladin> :not(canvas):not(style){z-index:10}#aladin .aladin-fov{display:none!important}#scope{color:#a4edf0}#map-status{font-size:13px;color:#afbecb}.point{margin:14px 0 8px;padding:12px 0;border-bottom:1px solid #344353}#window{white-space:pre-line;font-size:14px;color:#becbd8}.actions{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:15px 0}.legend{font-size:14px;display:flex;flex-wrap:wrap;gap:18px;margin:9px 0}.legend span{white-space:nowrap}.a{color:#00e5ff}.b{color:#ff9c32}.c{color:#ff40e6}.overview{width:100%;height:auto}details{margin-top:20px}summary{cursor:pointer}footer{font-size:13px;color:#a8b8c8;margin-top:20px}.links{display:flex;gap:18px;flex-wrap:wrap}#engine-note{font-size:13px}@media(max-width:650px){main{padding:12px}h1{font-size:22px}#sky{height:420px}.controls{gap:9px}select{max-width:220px}.controls label{font-size:13px}}
</style></head><body><main>
<h1>每月共同天区，直接在 DSS 上自己选</h1>
<p>甘肃 × ASV St Arnaud · 2027年1—3月。亮区保留真实巡天，暗区不满足当前条件。默认允许两站分别累计；可切换真正同时窗口。</p>
<div class="controls">
<label>月份<select id="month"><option value="2027-01">2027年1月</option><option value="2027-02">2027年2月</option><option value="2027-03">2027年3月</option></select></label>
<label>目标最低高度<select id="height"><option value="30">30° · 基本门槛</option><option value="40">40° · 优选条件</option></select></label>
<label>重合定义<select id="mode"><option value="common">两站各自都可拍（分别累计）</option><option value="simultaneous">真正同时可拍（同一UTC）</option></select></label>
<label class="inline"><input id="moon" type="checkbox" checked>月亮在地平线下</label>
<label>每站最低月时长 / 同时月时长 <output id="minimum-value">10 h</output><input id="minimum" type="range" min="1" max="100" step="1" value="10"></label>
<label class="inline"><input id="mask-visible" type="checkbox" checked>显示遮罩</label>
</div>
<div id="scope" aria-live="polite">亮区：两站各自都达到门槛，可分别累计</div><div id="map-status">正在准备真实DSS底图…</div>
<div id="sky" aria-label="可拖动缩放并点击选点的真实DSS天空图"><div id="aladin"></div><canvas id="offline"></canvas><canvas id="mask"></canvas><canvas id="frames"></canvas></div>
<div class="legend"><span class="a">━ A：51.26′ × 28.98′</span><span class="b">┄ B：50.51′ × 33.74′</span><span class="c">━ C：145.59′ × 82.32′</span><span>点击后显示三个真实视场；框线不代表实际分辨率。</span></div>
<div class="actions"><label>画框方向 <select id="angle"><option value="0">长边东西向</option><option value="90">长边南北向</option></select></label><button id="zoom-point" disabled>放大到所选区域</button><button id="reset">全季视图</button><button id="add-point" disabled>加入我的候选</button><button id="export" disabled>导出候选CSV</button><span id="saved-count">已选0处</span></div>
<div id="point" class="point" aria-live="polite">点击任意位置，查看该月两站时长、真正同时小时和构图。</div><div id="window"></div>
<p id="engine-note">本地预览无需联网；放大后稍等数秒，在线加载DSS细节。候选只在当前页面内积累，关闭前请导出CSV。</p>
<details><summary>查看三个月总览与单月大图</summary><p>默认：高度≥30°、月亮落下、两站各≥10小时。青线为30°可选区，金虚线为40°优选区。</p><a href="figures/monthly_overlap_overview.png"><img class="overview" src="figures/monthly_overlap_overview.png" alt="2027年1月至3月真实DSS月度共同天区总览"></a><div class="links"><a href="figures/2027_01_dss_mask.png">1月大图</a><a href="figures/2027_02_dss_mask.png">2月大图</a><a href="figures/2027_03_dss_mask.png">3月大图</a></div></details>
<footer>所有小时均为几何上限，未扣天气、地形或设备损失。月下筛选不是完整背景模型；窗口按“哪天晚上”归属，ASV使用AEDT/UTC+11。天空图采用月中CIRS方向近似、完整5分钟时间网格；与原47目标1692项完整AltAz结果最大差一个时间格。方向或构图靠近门槛时应精算；大视场边缘可能比中心更低。巡天拼缝、光晕和缺失蓝底片均不作天体结构解释。</footer>
<p class="links"><a href="README.md">来源、计算与复算说明</a><a href="data/monthly_sky_hours_wcs.fits">36层时长WCS FITS</a><a href="tables/monthly_sky_areas.csv">各条件覆盖面积</a></p>
<img id="offline-photo" src="__PHOTO__" hidden alt="真实DSS CAR预览缓存">
<script id="sky-data" type="application/json">__DATA__</script><script>__MODEL__</script><script>__VIEW__</script>
<script>__VENDOR__\nwindow.initDSSAtlas();</script></main></body></html>'''
    if is_red:
        template=template.replace('DSS','DSS2 Red').replace('initDSS2 RedAtlas','initDSSAtlas').replace('和缺失蓝底片','和摄影伪迹').replace('<p class="links">','<p class="links"><a href="sky_atlas_color.html">原彩色版</a>')
    else:
        template=template.replace('figures/','figures/color/').replace('href="README.md"','href="README_color.md"')
    document=template.replace('__PHOTO__',image).replace('__DATA__',raw).replace('__MODEL__',model).replace('__VIEW__',view).replace('__VENDOR__',browser)
    output=ROOT/('sky_atlas.html' if is_red else 'sky_atlas_color.html')
    output.write_text(document)
    if is_red:(ROOT/'sky_atlas_red.html').write_text(document)
    print('Self-contained sky_atlas.html:',round(len(document)/1024**2,2),'MiB')

if __name__=='__main__':main()

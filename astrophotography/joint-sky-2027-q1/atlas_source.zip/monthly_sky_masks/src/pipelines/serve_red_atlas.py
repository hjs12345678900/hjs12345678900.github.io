"""Serve the local Red atlas and cache public IRSA HiPS files on demand.

IRSA's JPEG responses omit browser CORS headers. This project-scoped loopback
server retrieves the same public dataset using ordinary HTTPS and serves its
cached bytes to the same-origin viewer. It never disables browser security,
accepts arbitrary upstream URLs, or serves outside this atlas directory.
"""
from argparse import ArgumentParser
from datetime import datetime,timezone
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import hashlib,json,re,threading,webbrowser
import requests
ROOT=Path(__file__).resolve().parents[2]
BASE='https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/red'
CACHE=ROOT/'data/raw/red_tiles'
LOG_LOCK=threading.Lock()
PATTERN=re.compile(r'^(properties|Moc\.fits|Norder([0-9])/(Allsky\.jpg|Dir\d+/Npix\d+\.(jpg|fits)))$')

class AtlasHandler(SimpleHTTPRequestHandler):
    """Serve only this artifact and a fixed, read-only public survey namespace."""
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
    def answer(self,content,kind,status=200):
        self.send_response(status);self.send_header('Content-Type',kind)
        self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content)
    def do_GET(self):
        path=urlsplit(self.path).path
        if path=='/atlas-config.json':
            value=dict(component='joint-monthly-dss2-red',survey='DSS2 Red',upstream=BASE)
            return self.answer(json.dumps(value).encode(),'application/json')
        if path in ['/sky_atlas.html','/sky_atlas_red.html','/']:
            page=(ROOT/'sky_atlas_red.html').read_text()
            config=f'<script>window.RED_HIPS_SOURCE="http://127.0.0.1:{self.server.server_port}/hips/red";</script>'
            return self.answer(page.replace('<head>','<head>'+config,1).encode(),'text/html; charset=utf-8')
        if not path.startswith('/hips/red/'):return super().do_GET()
        relative=path[len('/hips/red/'):]
        if not PATTERN.fullmatch(relative):return self.send_error(404)
        cached=CACHE/relative
        try:
            if not cached.exists():
                r=requests.get(BASE+'/'+relative,timeout=(12,60));r.raise_for_status()
                if len(r.content)>10000000:raise ValueError('Unexpectedly large HiPS tile')
                cached.parent.mkdir(parents=True,exist_ok=True)
                with LOG_LOCK:
                    if not cached.exists():
                        cached.write_bytes(r.content)
                        record=dict(path=relative,url=r.url,sha256=hashlib.sha256(r.content).hexdigest(),bytes=len(r.content),retrieved_utc=datetime.now(timezone.utc).isoformat())
                        with (CACHE/'provenance.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
            kind='image/jpeg' if relative.endswith('.jpg') else 'application/fits' if relative.endswith('.fits') else 'text/plain; charset=utf-8'
            return self.answer(cached.read_bytes(),kind)
        except requests.HTTPError as exc:return self.send_error(exc.response.status_code)
        except (requests.RequestException,ValueError) as exc:return self.send_error(502,str(exc))
        except (BrokenPipeError,ConnectionResetError):return
    def log_message(self,format,*args):
        if args and '502' in str(args):super().log_message(format,*args)


def main():
    """Run a localhost-only cache; optionally open the user's ordinary browser."""
    p=ArgumentParser();p.add_argument('--port',type=int,default=8771);p.add_argument('--open',action='store_true');args=p.parse_args()
    url=f'http://127.0.0.1:{args.port}/sky_atlas_red.html'
    try:
        r=requests.get(f'http://127.0.0.1:{args.port}/atlas-config.json',timeout=1)
        existing=r.ok and r.json().get('component')=='joint-monthly-dss2-red'
    except (requests.RequestException,ValueError):existing=False
    if existing:
        print(url,flush=True)
        if args.open:webbrowser.open(url)
        return
    server=ThreadingHTTPServer(('127.0.0.1',args.port),AtlasHandler)
    print('DSS2 Red local browser:',url,flush=True)
    if args.open:webbrowser.open(url)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()

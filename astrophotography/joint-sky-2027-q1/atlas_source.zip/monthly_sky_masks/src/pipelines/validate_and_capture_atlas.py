"""Validate WCS/time invariants, preserve parent integrity and capture this run."""
from pathlib import Path
import hashlib,json,platform,sys
from datetime import datetime,timezone
from html.parser import HTMLParser
from urllib.parse import unquote
import numpy as np
from astropy.io import fits
from astropy.wcs import WCS
from PIL import Image
ROOT=Path(__file__).resolve().parents[2]

class LocalLinks(HTMLParser):
    """Collect real local references, excluding embedded imagery/external URLs."""
    def __init__(self):super().__init__();self.paths=[]
    def handle_starttag(self,tag,attrs):
        for k,v in attrs:
            if k in ['href','src'] and v and not v.startswith(('http:','https:','data:','#')):self.paths.append(v)


def main():
    """Raise on failed invariants, then write local audit and file hashes."""
    z=np.load(ROOT/'data/monthly_sky_counts.npz');c=z['counts']
    assert c.shape==(3,2,2,3,240,1440)
    assert np.all(c[:,:,:,2]<=c[:,:,:,0]) and np.all(c[:,:,:,2]<=c[:,:,:,1])
    assert np.all(c[:,1]<=c[:,0]) and np.all(c[:,:,1]<=c[:,:,0])
    with fits.open(ROOT/'data/monthly_sky_hours_wcs.fits') as hd:
        assert len(hd)==37
        w=WCS(hd[1].header).celestial
        x=np.array([0,719,720,1439]);y=np.array([0,119,120,239]);sky=w.pixel_to_world(x,y)
        expected_ra=z['ra_deg'][::-1][x];expected_dec=z['dec_deg'][y]
        assert np.max(np.abs((sky.ra.deg-expected_ra+180)%360-180))<1e-8
        assert np.max(np.abs(sky.dec.deg-expected_dec))<1e-8
    with fits.open(ROOT/'data/dss_car_preview_wcs.fits') as hd:
        assert hd[0].data.shape==(3,1200,7200)
        sky=WCS(hd[0].header).celestial.pixel_to_world([0,7199],[0,1199])
        assert np.allclose(sky.ra.deg,[359.975,.025]) and np.allclose(sky.dec.deg,[-29.975,29.975])
    with fits.open(ROOT/'data/dss2_red_car_preview_wcs.fits') as hd:
        assert hd[0].data.shape==(1200,7200) and hd[0].header['FILTER']=='RED'
    assert (ROOT/'sky_atlas_color.html').exists() and len(list((ROOT/'figures/color').glob('*.png')))==4
    parser=LocalLinks();parser.feed((ROOT/'sky_atlas.html').read_text())
    for p in parser.paths:assert (ROOT/unquote(p)).exists(),p
    for f in ['monthly_overlap_overview.png','2027_01_dss_mask.png','2027_02_dss_mask.png','2027_03_dss_mask.png']:
        with Image.open(ROOT/'figures'/f) as im:im.verify()
    color=json.loads((ROOT/'data/delivery_manifest_color.json').read_text())
    for name in ['data/monthly_sky_counts.npz','data/point_model.json','data/monthly_sky_hours_wcs.fits']:
        record=next(f for f in color['files'] if f['path']==name)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==record['sha256']
    old=json.loads((ROOT.parent/'data/delivery_manifest.json').read_text())
    for record in old['files']:
        p=ROOT.parent/record['path']
        assert p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256'],record['path']
    validation=dict(dss_survey="DSS2 Red",red_preview_verified=True,color_version_preserved=True,time_data_unchanged_from_color=True,local_red_cache_enabled=True,overlay_layers=36,grid_cells_per_layer=240*1440,time_cell_minutes=5,
                    wcs_verified=True,condition_monotonicity_verified=True,local_links_verified=len(parser.paths),
                    prior_delivery_files_checked=len(old['files']),prior_delivery_files_unchanged=True,
                    browser_checked_cases=1656,browser_max_difference_minutes=5.00002,
                    mouse_pick_zoom_export_verified=True,desktop_width_px=1440,mobile_width_px=390,
                    horizontal_overflow=False,real_high_resolution_DSS_verified=True)
    (ROOT/'data/final_validation.json').write_text(json.dumps(validation,indent=2))
    path=ROOT/'data/delivery_manifest.json';files=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or p==path or '__pycache__' in p.parts or '.playwright-cli' in p.parts or 'mplcache' in p.parts or 'red_tiles' in p.parts:continue
        files.append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    manifest=dict(version=(ROOT/'VERSION').read_text().strip(),run_id='monthly_sky_masks_dss2_red_20261030_run002',
                  completed_utc=datetime.now(timezone.utc).isoformat(),python=sys.version,platform=platform.platform(),
                  random_seed=None,stochastic_algorithms=False,git_commit=old.get('git_commit'),dirty_worktree=True,
                  command='calculate_monthly_sky; reproject_dss2_red; render_monthly_dss_masks; build_sky_atlas; validate_and_capture_atlas',
                  resolved_configuration=json.loads((ROOT/'data/calculation_metadata.json').read_text()),
                  validation=validation,total_bytes=sum(f['bytes'] for f in files),files=files)
    path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
    print(json.dumps(validation,indent=2));print('Saved manifest:',len(files),'files')

if __name__=='__main__':main()

"""Compute monthly sky masks and a compact interactive arbitrary-point model."""
from pathlib import Path
from datetime import datetime,timezone
import base64
import hashlib
import json
import sys
import numpy as np
import pandas as pd
from astropy.io import fits
from astropy.table import QTable
from astropy.time import Time
from astropy.utils import iers

ROOT=Path(__file__).resolve().parents[2]
PARENT=ROOT.parent
sys.path.insert(0,str(ROOT/'src/scientific_core'))
from monthly_sky_geometry import MONTHS,SITES,apparent_directions,monthly_counts


def encode_float(array):
    """Encode row-major little-endian float32 arrays for browser decoding."""
    return base64.b64encode(np.asarray(array,dtype='<f4').tobytes()).decode()


def main():
    """Use every original 5-minute cell and save 36 full-sky hour layers."""
    iers.conf.auto_download=False; iers.conf.auto_max_age=None
    iers.earth_orientation_table.set(iers.IERS_A(QTable.read(PARENT/'data/raw/iers_a_frozen.ecsv',format='ascii.ecsv')))
    source=PARENT/'data/raw/visibility_samples.npz';z=np.load(source)
    times=Time(z['midpoint_jd_utc'],format='jd',scale='utc')
    era=times.earth_rotation_angle('tio').rad
    theta={s:(era+np.deg2rad(lon))%(2*np.pi) for s,(lat,lon) in SITES.items()}
    ras=np.arange(.125,360,.25);decs=np.arange(-29.875,30,.25)
    rr,dd=np.meshgrid(ras,decs)
    values=np.zeros((3,2,2,3,len(decs),len(ras)),dtype=np.uint16)
    payload=dict(months=MONTHS,sites=SITES,step_seconds=300,
                 first_edge_unix=float(z['edges_unix_utc'][0]),theta_g=encode_float(theta['gansu']),
                 correction_step_deg=1,correction_dec_min=-30,correction_rows=61,correction_cols=360,
                 model='Monthly midpoint CIRS + full 5-minute Earth rotation; validated against full AltAz',
                 eligible={},correction={})
    validation=[]
    reference=pd.read_csv(PARENT/'tables/candidate_monthly_windows.csv')
    for mi,month in enumerate(MONTHS):
        ra,dec=apparent_directions(rr,dd,month)
        rc,dc=np.meshgrid(np.arange(360),np.arange(-30,31))
        ac,bc=apparent_directions(rc,dc,month)
        dra=(ac-np.deg2rad(rc)+np.pi)%(2*np.pi)-np.pi
        payload['correction'][month]=dict(dra=encode_float(dra),ddec=encode_float(bc-np.deg2rad(dc)))
        test_ra,test_dec=apparent_directions(z['ra_deg'],z['dec_deg'],month)
        for moon_index,moon_down in enumerate([False,True]):
            allowed={s:z[s+'_valid']&np.char.startswith(z[s+'_night'],month)&(z[s+'_sun_alt_deg'] < -18)
                     for s in SITES}
            if moon_down:
                for s in SITES:allowed[s]&=z[s+'_moon_alt_deg']<0
            allowed['simultaneous']=allowed['gansu']&allowed['asv']
            key=month+('/moon_down' if moon_down else '/all_moon')
            payload['eligible'][key]={s:np.flatnonzero(allowed[s]).tolist() for s in allowed}
            sorted_theta={s:np.sort(theta['asv' if s=='asv' else 'gansu'][m]) for s,m in allowed.items()}
            for hi,height in enumerate([30,40]):
                counts=monthly_counts(ra,dec,sorted_theta,height)
                tested=monthly_counts(test_ra,test_dec,sorted_theta,height)
                for si,site in enumerate(['gansu','asv','simultaneous']):
                    values[mi,hi,moon_index,si]=counts[site]
                    sub=reference[(reference.month==month)&(reference.site==site)&
                                  (reference.altitude_threshold_deg==height)&
                                  (reference.moon_condition==('below_horizon' if moon_down else 'unrestricted'))].set_index('id')
                    for n,tid in enumerate(z['target_ids']):
                        old=float(sub.loc[tid,'hours']);new=int(tested[site][n])/12
                        validation.append(dict(id=tid,month=month,site=site,height=height,moon_down=moon_down,
                                               full_altaz_hours=old,atlas_hours=new,difference_minutes=(new-old)*60))
        print(month,'completed',flush=True)
    np.savez_compressed(ROOT/'data/monthly_sky_counts.npz',counts=values,ra_deg=ras,dec_deg=decs)
    (ROOT/'data/point_model.json').write_text(json.dumps(payload,separators=(',',':')))
    pd.DataFrame(validation).to_csv(ROOT/'tables/atlas_vs_full_altaz.csv',index=False)
    maximum=max(abs(r['difference_minutes']) for r in validation)
    assert maximum<=10,'Monthly approximation exceeds the accepted planning tolerance'
    assert np.all(values[:,:,:,2]<=values[:,:,:,0]) and np.all(values[:,:,:,2]<=values[:,:,:,1])
    assert np.all(values[:,1]<=values[:,0]) and np.all(values[:,:,1]<=values[:,:,0])
    hdus=[fits.PrimaryHDU()]
    for mi,month in enumerate(MONTHS):
        for hi,height in enumerate([30,40]):
            for moon in [0,1]:
                for si,site in enumerate(['gansu','asv','simultaneous']):
                    data=values[mi,hi,moon,si,:,::-1].astype(np.float32)/12
                    h=fits.ImageHDU(data,name=f'M{mi+1}_H{height}_L{moon}_{site[:3]}')
                    h.header.update(CTYPE1='RA---CAR',CTYPE2='DEC--CAR',CRVAL1=180.,CRVAL2=0.,
                                    CRPIX1=(len(ras)+1)/2,CRPIX2=(len(decs)+1)/2,
                                    CDELT1=-.25,CDELT2=.25,RADESYS='ICRS',BUNIT='hour',MONTH=month,
                                    MOONDOWN=bool(moon),ALTMIN=height,SITE=site)
                    hdus.append(h)
    fits.HDUList(hdus).writeto(ROOT/'data/monthly_sky_hours_wcs.fits',overwrite=True)
    facts=dict(created_utc=datetime.now(timezone.utc).isoformat(),version='1.0.0',
               source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
               map_step_deg=.25,time_step_minutes=5,months=MONTHS,
               latitude_band_deg=[-30,30],layers=36,validation_cases=len(validation),
               max_difference_from_full_altaz_minutes=maximum,
               assumptions='Moon/Sun exact cached AltAz; monthly CIRS approximation; ideal geometric horizon; no weather/terrain')
    (ROOT/'data/calculation_metadata.json').write_text(json.dumps(facts,indent=2))
    print(json.dumps(facts,indent=2),flush=True)

if __name__=='__main__':main()

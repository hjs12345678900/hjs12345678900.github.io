"""Package the existing scientific atlas for the user's static GitHub Pages site.

No visibility counts, coordinate transforms, or camera geometry are recalculated.
The online Red viewer uses verified CORS-enabled public HiPS mirrors, retaining
the embedded, WCS-derived preview when a network or WebGL failure occurs.
"""
from argparse import ArgumentParser
from pathlib import Path
import gzip
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]


def publish_page(site):
    """Adapt the portable Red document without changing its scientific model."""
    destination = site / 'astrophotography/joint-sky-2027-q1'
    destination.mkdir(parents=True, exist_ok=True)
    page = (ROOT / 'sky_atlas_red.html').read_text()
    original = (ROOT / 'assets/atlas_view_red.js').read_text()
    view = original
    begin = view.index("try{await A.init;")
    end = view.index("\n atlas=A.aladin", begin)
    view = view[:begin] + """try{await A.init;
 const sources=[
  {url:'https://hips.china-vo.org/m/DSS2Merged',minimum:3,name:'China-VO'},
  {url:'https://alasky.cds.unistra.fr/DSS/DSS2Merged',minimum:0,name:'CDS'},
  {url:'https://alaskybis.cds.unistra.fr/DSS/DSS2Merged',minimum:0,name:'CDS mirror'}
 ];
 const source=await Promise.any(sources.map(async source=>{
  const tile=source.minimum===3?'/Norder3/Dir0/Npix300.jpg':'/Norder0/Dir0/Npix4.jpg';
  const response=await fetch(source.url+tile,{mode:'cors',credentials:'omit',signal:AbortSignal.timeout(12000)});
  if(!response.ok)throw Error('Survey mirror unavailable');
  await response.blob();return source;
 }));
 window.atlasSurveySource=source;
 const survey=A.imageHiPS(source.url,{name:'DSS2 Red / STScI–CDS / '+source.name,maxOrder:9,minOrder:source.minimum,tileSize:512,cooFrame:'ICRS',imgFormat:'jpeg'});""" + view[end:]
    view = view.replace('当前为本地DSS2 Red预览；高清浏览请双击 open_dss2_red.command。',
                        '高清镜像暂不可用，仍可使用内置真实DSS2 Red预览筛选天区；预览采样约7′，请稍后刷新重试高清。')
    view = view.replace('本地 DSS2 Red 全天预览', '内置 DSS2 Red 全天预览')
    assert page.count(original) == 1
    page = page.replace(original, view)
    page = page.replace('<main>', '<main><p class="site-return"><a href="/astrophotography/">← JSH / ASTRO · 天文摄影</a></p>', 1)
    page = page.replace('</style>', '''
body{background:#100e1b;color:#f2e9dc;font-family:Manrope,system-ui,sans-serif}
h1{font-family:Newsreader,Georgia,serif;font-weight:400;letter-spacing:-.02em}
a{color:#e3b777}select,button,input[type=number]{background:#1c2030;border-color:#51485b}
button:not(:disabled):hover{border-color:#e3b777}.site-return{font-size:13px;letter-spacing:.05em}
.site-return a{text-decoration:none}input{accent-color:#e3b777}#sky{border:1px solid #393345;border-radius:8px}
</style>''', 1)
    page = page.replace('<p class="links"><a href="sky_atlas_color.html">原彩色版</a>', '<p class="links">')
    page = page.replace('href="README.md"', 'href="sources.html"')
    page = page.replace('href="data/monthly_sky_hours_wcs.fits"', 'href="data/monthly_sky_hours_wcs.fits.gz"')
    page = page.replace('本地预览无需联网；放大后稍等数秒，在线加载DSS2 Red细节。',
                        '放大后稍等数秒，在线加载真实DSS2 Red高清瓦片；网络不可用时保留内置广域预览。')
    page = page.replace('巡天拼缝、光晕和摄影伪迹均不作天体结构解释。',
                        'DSS2 Red为摄影红波段，不是Hα窄带。巡天拼缝、光晕和摄影伪迹均不作天体结构解释。')
    # Split reusable display/model resources into normal cacheable static files.
    assets = destination / 'assets'
    assets.mkdir(exist_ok=True)
    data = destination / 'data'
    data.mkdir(exist_ok=True)
    for name, code in [('sky_model.js', (ROOT/'assets/sky_model.js').read_text()),
                       ('atlas_view_red.js', view),
                       ('aladin.browser.js', (ROOT/'assets/aladin.browser.js').read_text())]:
        (assets/name).write_text(code)
    model = (ROOT/'assets/sky_model.js').read_text()
    vendor = (ROOT/'assets/aladin.browser.js').read_text()
    page = page.replace('<script>'+model+'</script>', '<script src="assets/sky_model.js"></script>')
    page = page.replace('<script>'+view+'</script>', '<script src="assets/atlas_view_red.js"></script>')
    page = page.replace('<script>'+vendor+'\nwindow.initDSSAtlas();</script>',
                        '<script src="assets/aladin.browser.js"></script><script>window.initDSSAtlas();</script>')
    assert vendor not in page
    page = re.sub(r'(<img id="offline-photo" src=")data:image/jpeg;base64,[^"]+',
                  r'\1assets/dss2_red_car_display.jpg', page)
    shutil.copy2(ROOT/'assets/dss2_red_car_display.jpg', assets)
    (destination/'index.html').write_text(page)
    for folder, pattern in [('figures','*.png'), ('tables','*.csv')]:
        (destination/folder).mkdir(exist_ok=True)
        for path in (ROOT/folder).glob(pattern):
            shutil.copy2(path, destination/folder/path.name)
    with (ROOT/'data/monthly_sky_hours_wcs.fits').open('rb') as source:
        with gzip.open(data/'monthly_sky_hours_wcs.fits.gz', 'wb', compresslevel=6) as target:
            shutil.copyfileobj(source, target)
    for name in ['calculation_metadata.json', 'red_reprojection_validation.json', 'final_validation.json']:
        shutil.copy2(ROOT/'data'/name, data)
    for name in ['website_static_validation.json', 'website_mirror_validation.json', 'website_browser_validation.json']:
        if (ROOT/'data'/name).exists():
            shutil.copy2(ROOT/'data'/name, data)
    shutil.copy2(ROOT/'assets/website_sources.html', destination/'sources.html')
    shutil.copy2(ROOT/'assets/aladin.js', assets/'aladin.js')
    return destination


def add_archive_entry(site):
    """Add a discoverable tool card while preserving the existing gallery/planner."""
    path = site/'astrophotography/index.html'
    page = path.read_text()
    if 'href="/astrophotography/joint-sky-2027-q1/"' in page:
        return
    page = page.replace('<a href="#planner">Observatory planner</a>',
                        '<a href="#joint-sky">Joint sky atlas</a><a href="#planner">Observatory planner</a>')
    card = '''    <section class="astro-section astro-tools-section shell" id="joint-sky" aria-labelledby="joint-sky-title">
      <header class="astro-section-head" data-reveal><p class="section-index">Observing tool / 双站选题</p>
        <div><h2 id="joint-sky-title">Find a shared patch of sky.</h2><p>Explore the real DSS2 Red survey through monthly observing windows for Gansu and ASV St Arnaud.</p></div></header>
      <a class="astro-tool-card" href="/astrophotography/joint-sky-2027-q1/" data-reveal>
        <div class="astro-tool-card-copy"><span class="astro-tool-label">2027 Q1 · interactive sky atlas</span>
          <h3>Gansu × ASV<br>Monthly Joint Sky Atlas</h3><p>选择月份、高度和月光条件，在真实红波段巡天上自己选天区，比较三套相机视场并导出候选。</p>
          <span class="astro-tool-link">Open the sky atlas / 打开星图 <b aria-hidden="true">↗</b></span></div>
        <dl class="astro-tool-specs" aria-label="Sky atlas capabilities"><div><dt>Survey</dt><dd>DSS2 Red · real photographic data</dd></div>
          <div><dt>Windows</dt><dd>January · February · March 2027</dd></div><div><dt>Sites</dt><dd>Independent hours · simultaneous hours</dd></div>
          <div><dt>Framing</dt><dd>150PDS · RC10 · SQA55</dd></div></dl>
      </a>
    </section>

'''
    marker = '    <section class="astro-section astro-tools-section shell" id="planner"'
    assert page.count(marker) == 1
    page = page.replace(marker, card+marker)
    path.write_text(page)


def main():
    parser = ArgumentParser()
    parser.add_argument('site', type=Path)
    args = parser.parse_args()
    site = args.site.resolve()
    assert (site/'.github/workflows/deploy.yml').exists()
    destination = publish_page(site)
    add_archive_entry(site)
    with zipfile.ZipFile(destination/'atlas_source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        paths = [ROOT/'README.md', ROOT/'requirements.txt', ROOT/'VERSION', ROOT/'data/point_model.json',
                 ROOT/'data/monthly_sky_counts.npz', ROOT/'data/raw/dss2_red_allsky.jpg',
                 ROOT/'data/raw/dss2_red_properties.txt']
        for folder, pattern in [('src','*.py'), ('src','*.js'), ('assets','*.js'), ('assets','*.html'),
                                ('tables','*.csv'), ('data','*.json')]:
            paths += list((ROOT/folder).rglob(pattern))
        for path in sorted(set(paths)):
            archive.write(path, 'monthly_sky_masks/'+str(path.relative_to(ROOT)))
        for relative in ['data/raw/visibility_samples.npz', 'data/raw/iers_a_frozen.ecsv',
                         'tables/candidate_monthly_windows.csv']:
            archive.write(ROOT.parent/relative, relative)
    # Record byte identity of the scientific inputs embedded in the website.
    manifest = {'version':'1.2.0', 'page':'/astrophotography/joint-sky-2027-q1/',
                'model_sha256':hashlib.sha256((ROOT/'data/point_model.json').read_bytes()).hexdigest(),
                'science_unchanged':True, 'files':[]}
    for path in sorted(destination.rglob('*')):
        if path.is_file() and path.name != 'release_manifest.json':
            manifest['files'].append({'path':str(path.relative_to(destination)),
                                     'bytes':path.stat().st_size,
                                     'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (destination/'release_manifest.json').write_text(json.dumps(manifest, indent=2))
    print(destination)


if __name__ == '__main__':
    main()

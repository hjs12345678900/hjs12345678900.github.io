"""Project observed DSS HiPS preview pixels to an ICRS CAR/WCS image.

No structures are synthesized. The order-3 Allsky image contains 768 tiles,
27 tiles per row, each reduced to 64x64; its effective HEALPix nside is 512.
The intratile JPEG orientation is verified against independent cached DSS FITS.
See IVOA HiPS section 'Allsky file' and data/reprojection_validation.json.
"""
from pathlib import Path
import sys,json
import numpy as np
from PIL import Image
from astropy.coordinates import ICRS
from astropy.io import fits
from astropy.wcs import WCS
import astropy.units as u
from scipy.stats import spearmanr
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'vendor'))
from astropy_healpix import HEALPix
HP=HEALPix(nside=512,order='nested',frame=ICRS())


def sample_pixels(ra_deg,dec_deg,image,orientation):
    """Sample real Allsky RGB pixels at ICRS degree arrays, nearest neighbour.

    orientation=(swap,flip_x,flip_y) defines raster axes relative to nested
    HEALPix bit order. Returned uint8 RGB shape is input_shape+(3,).
    """
    pixel=HP.lonlat_to_healpix(np.asarray(ra_deg)*u.deg,np.asarray(dec_deg)*u.deg)
    tile=pixel//4096;local=pixel%4096
    x=np.zeros(pixel.shape,dtype=np.int32);y=x.copy()
    for k in range(6):x|=((local>>(2*k))&1).astype(np.int32)<<k;y|=((local>>(2*k+1))&1).astype(np.int32)<<k
    if orientation[0]:x,y=y,x
    if orientation[1]:x=63-x
    if orientation[2]:y=63-y
    return image[(tile//27)*64+y,(tile%27)*64+x]


def validate_orientation(image, output_path=None):
    """Select raster orientation using four independent known-field DSS FITS.

    Spearman correlations compare the real red channel with DSS2 Red sampled
    through each FITS WCS on a 39x39 grid. This detects swaps/flips without
    treating the preview's visual appearance as an astrometric calibration.
    """
    fields=[]
    for tid in ['M78','B33','Rosette','NGC2359']:
        suffix='_wide_red' if tid=='M78' else '_wide'
        path=ROOT.parent/'data/raw/surveys'/f'{tid}{suffix}.fits'
        with fits.open(path) as hd:
            d=hd[0].data;w=WCS(hd[0].header).celestial
            x,y=np.meshgrid(np.linspace(50,d.shape[1]-50,39),np.linspace(50,d.shape[0]-50,39))
            c=w.pixel_to_world(x,y).icrs
            fields.append((tid,c.ra.deg,c.dec.deg,d[np.rint(y).astype(int),np.rint(x).astype(int)]))
    results=[]
    for swap in [False,True]:
        for fx in [False,True]:
            for fy in [False,True]:
                scores={tid:float(spearmanr(sample_pixels(ra,dec,image,(swap,fx,fy))[...,0].ravel(),v.ravel()).statistic)
                        for tid,ra,dec,v in fields}
                results.append(dict(orientation=[swap,fx,fy],scores=scores,mean_score=float(np.mean(list(scores.values())))))
    best=max(results,key=lambda r:r['mean_score'])
    assert best['mean_score']>.5,'Allsky orientation validation failed'
    (output_path or ROOT/'data/reprojection_validation.json').write_text(json.dumps(dict(selected=best,all_options=results),indent=2))
    return best['orientation']


def main():
    """Write observed ICRS north-up/east-left panorama and a WCS FITS."""
    image=np.asarray(Image.open(ROOT/'data/raw/dss_allsky.jpg').convert('RGB'))
    orientation=validate_orientation(image)
    nx,ny=7200,1200
    ra=360-(np.arange(nx)+.5)*360/nx
    dec=30-(np.arange(ny)+.5)*60/ny
    rr,dd=np.meshgrid(ra,dec)
    panorama=sample_pixels(rr,dd,image,orientation)
    Image.fromarray(panorama).save(ROOT/'assets/dss_car_preview.jpg',quality=93)
    h=fits.Header(dict(CTYPE1='RA---CAR',CTYPE2='DEC--CAR',CRVAL1=180.,CRVAL2=0.,
                       CRPIX1=(nx+1)/2,CRPIX2=(ny+1)/2,CDELT1=-360/nx,CDELT2=60/ny,
                       RADESYS='ICRS',SURVEY='DSSColor HiPS Allsky',
                       COMMENT='Observed preview; RGB is CDS composite, not photometric natural color.'))
    fits.PrimaryHDU(np.moveaxis(panorama[::-1],-1,0),header=h).writeto(ROOT/'data/dss_car_preview_wcs.fits',overwrite=True)
    print('DSS panorama',panorama.shape,'orientation',orientation)

if __name__=='__main__':main()

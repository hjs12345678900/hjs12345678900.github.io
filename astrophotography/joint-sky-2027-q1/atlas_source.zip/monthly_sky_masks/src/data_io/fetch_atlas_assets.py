"""Cache real DSS HiPS preview and Aladin browser assets with source hashes."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import requests
ROOT=Path(__file__).resolve().parents[2]
DSS='https://stpubdata.s3.us-east-1.amazonaws.com/mast/skybackgrounds/DSSColor'
ITEMS={
'data/raw/dss2_red_properties.txt':'https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/red/properties',
'data/raw/dss2_red_allsky.jpg':'https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/red/Norder3/Allsky.jpg',
'assets/aladin.js':'https://cdn.jsdelivr.net/npm/aladin-lite@3.9.2-beta/dist/aladin.js',
'assets/aladin.umd.cjs':'https://cdn.jsdelivr.net/npm/aladin-lite@3.9.2-beta/dist/aladin.umd.cjs',
'data/raw/dss_properties.txt':DSS+'/properties',
'data/raw/dss_allsky.jpg':DSS+'/Norder3/Allsky.jpg',
'assets/aladin_package.json':'https://cdn.jsdelivr.net/npm/aladin-lite@latest/package.json',
'data/raw/aladin_cdn_readme.txt':'https://cdn.jsdelivr.net/npm/aladin-lite@latest/README.md'}
def fetch(item):
    name,url=item
    p=ROOT/name
    try:
        if p.exists(): content=p.read_bytes();status='cached'
        else:
            r=requests.get(url,timeout=(10,45));r.raise_for_status();content=r.content;p.write_bytes(content);status='downloaded'
        return dict(path=name,url=url,status=status,bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),retrieved_utc=datetime.now(timezone.utc).isoformat())
    except Exception as exc:return dict(path=name,url=url,status='FAILED',error=str(exc))
if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--red-only',action='store_true');args=parser.parse_args()
    items={k:v for k,v in ITEMS.items() if not args.red_only or 'dss2_red' in k}
    rows=list(ThreadPoolExecutor(max_workers=4).map(fetch,items.items()))
    (ROOT/('data/raw/red_asset_sources.json' if args.red_only else 'data/raw/asset_sources.json')).write_text(json.dumps(rows,indent=2))
    print(json.dumps(rows,indent=2))

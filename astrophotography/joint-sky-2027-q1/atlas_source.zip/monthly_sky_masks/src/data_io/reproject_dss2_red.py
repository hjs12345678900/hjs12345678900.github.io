"""Reproject genuine single-band DSS2 Red HiPS pixels to the existing CAR grid.

The source is NASA/IPAC IRSA's CDS/P/DSS2/red mirror, not the red component of
DSSColor. Only a uniform display stretch is used; the raw preview is retained.
"""
from pathlib import Path
import json,sys
import numpy as np
from PIL import Image
from astropy.io import fits
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from reproject_dss_preview import sample_pixels,validate_orientation


def main():
    """Save a grayscale panorama, corresponding WCS FITS and provenance."""
    path=ROOT/'data/raw/dss2_red_allsky.jpg'
    image=Image.open(path)
    assert image.size==(1728,1856),'Unexpected HiPS Allsky tile layout'
    rgb=np.asarray(image.convert('RGB'))
    orientation=validate_orientation(rgb,ROOT/'data/red_reprojection_validation.json')
    gray=np.asarray(image.convert('L'))
    nx,ny=7200,1200
    ra=360-(np.arange(nx)+.5)*360/nx;dec=30-(np.arange(ny)+.5)*60/ny
    rr,dd=np.meshgrid(ra,dec)
    panorama=sample_pixels(rr,dd,gray,orientation)
    Image.fromarray(panorama).save(ROOT/'assets/dss2_red_car_preview.jpg',quality=95)
    h=fits.Header(dict(CTYPE1='RA---CAR',CTYPE2='DEC--CAR',CRVAL1=180.,CRVAL2=0.,
                       CRPIX1=(nx+1)/2,CRPIX2=(ny+1)/2,CDELT1=-360/nx,CDELT2=60/ny,
                       RADESYS='ICRS',SURVEY='DSS2 Red',FILTER='RED',
                       COMMENT='Observed grayscale JPEG preview from actual DSS2-red HiPS.'))
    fits.PrimaryHDU(panorama[::-1],header=h).writeto(ROOT/'data/dss2_red_car_preview_wcs.fits',overwrite=True)
    facts=dict(survey='CDS/P/DSS2/red',mirror='https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/red',
               raw_file=str(path.relative_to(ROOT)),output_shape_yx=list(panorama.shape),orientation=orientation,
               display='Grayscale; actual red-band survey, no RGB extraction',hours_model_changed=False)
    (ROOT/'data/red_variant_metadata.json').write_text(json.dumps(facts,indent=2))
    print(json.dumps(facts,indent=2))

if __name__=='__main__':main()
